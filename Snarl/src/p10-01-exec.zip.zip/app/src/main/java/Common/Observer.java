package Common;

import Game.Model.GameState;

public interface Observer {
    void renderView(GameState gameState);
}
