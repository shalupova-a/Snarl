package Common;

import Common.Observer;
import Game.Model.GameState;

import java.util.List;

public interface GameNotifier {
    void notifySubscribers(GameState gameState);
    void registerSubscriber(Observer o);
    void removeSubscriber(Observer o);

}
