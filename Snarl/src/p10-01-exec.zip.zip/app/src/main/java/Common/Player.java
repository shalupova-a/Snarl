package Common;

import Game.Model.Coordinate;
import Game.Model.GameState;

public interface Player {
    void updatePlayerPosition(Coordinate playerPos) throws Exception;
    void updatePlayerPosition(Integer[] playerPos) throws Exception;
    void promptPlayerMove();
}
