package Common;

public interface GameView {
}
