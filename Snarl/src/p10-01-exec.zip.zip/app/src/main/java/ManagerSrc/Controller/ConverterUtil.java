package ManagerSrc.Controller;

import Game.Model.Coordinate;
import Game.Model.Item;
import Game.Model.ItemType;
import ManagerSrc.Hallway;
import ManagerSrc.Level;
import ManagerSrc.Object;
import ManagerSrc.Room;

import java.util.LinkedList;
import java.util.List;

public class ConverterUtil {

    public static Game.Model.Level convertLevelFromJson(Level level) throws Exception {
        List<Game.Model.Level> levels = new LinkedList<>();
        int levelCount = 1;
        List<Game.Model.Room> rooms = new LinkedList<>();
        int roomCount = 1;

        // Map rooms
        for (Room room : level.getRooms()) {
            int width = room.getBounds().getColumns();
            int height = room.getBounds().getRows();
            Coordinate origin = new Coordinate(room.getOrigin()[0], room.getOrigin()[1], roomCount);
            rooms.add(new Game.Model.Room(origin, width, height, roomCount++, room.getLayout()));
        }

//            Map Hallways
        List<Game.Model.Hallway> hallways = new LinkedList<>();
        for (Hallway hallway : level.getHallways()) {
            Coordinate from = new Coordinate(hallway.getFrom()[0], hallway.getFrom()[1]);
            Coordinate to = new Coordinate(hallway.getTo()[0], hallway.getTo()[1]);
            List<Coordinate> wayPoints = new LinkedList<>();
            for (Integer[] wayPoint : hallway.getWaypoints()) {
                wayPoints.add(new Coordinate(wayPoint[0], wayPoint[1]));
            }
            hallways.add(new Game.Model.Hallway(roomCount++, from, to, wayPoints));
        }

        // Map Items from object
        List<Item> items = new LinkedList<>();
        for (Object object : level.getObjects()) {
            // TODO need to fix this if many objects get added later on
            ItemType itemType = object.getType().equals("key") ? ItemType.KEY : ItemType.EXIT;
            items.add(new Item(new Coordinate(object.getPosition()[0], object.getPosition()[1]), itemType));
        }

        return new Game.Model.Level(levelCount++, rooms, hallways, items);
    }
}
