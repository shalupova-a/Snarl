package ManagerSrc.Controller;

import ManagerSrc.Actor;

public class CombatSystem {

    private static CombatSystem instance;

    public CombatSystem() {
    }

    public static CombatSystem getInstance() {
        if (instance == null) {
            instance = new CombatSystem();
        }
        return instance;
    }

    public static void duel(Actor player, Actor adversary) {
        setHp(player, getDamageFrom(player, adversary.getDefense()));

        if (adversary.getHitPoints() != 0) {
            setHp(player, getDamageFrom(adversary, player.getDefense()));
        }
    }

    private static int getDamageFrom(Actor actor, int opponentDefense) {
        return (actor.getAttack() * actor.getModifier()) - opponentDefense;
    }

    private static void setHp(Actor actor, int opponentDamage) {
        actor.setHitPoints(Math.min(0, actor.getHitPoints() - opponentDamage));
    }
}
