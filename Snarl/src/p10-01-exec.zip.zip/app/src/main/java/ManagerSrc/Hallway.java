package ManagerSrc;

import Game.Model.Coordinate;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Hallway {

    private String type;
    private Integer[] from;
    private Integer[] to;
    private Integer[][] waypoints;

    @JsonIgnore
    private List<Room> sections;

    public Hallway() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer[] getFrom() {
        return from;
    }

    public void setFrom(Integer[] from) {
        this.from = from;
    }

    public Integer[] getTo() {
        return to;
    }

    public void setTo(Integer[] to) {
        this.to = to;
    }

    public Integer[][] getWaypoints() {
        return waypoints;
    }

    public void setWaypoints(Integer[][] waypoints) {
        this.waypoints = waypoints;
    }

    public Room sectionCreator(Integer[] start, Integer[] end) {
        ObjectMapper o = new ObjectMapper();
        if (start[0].equals(end[0])) {
            if(start[1] > end[1]) {
                Integer[] temp = start;
                start = end;
                end = temp;
            }

            return new Room("room", start, new Bounds(1, (end[1] - start[1]) + 1), null);
        } else if (start[1].equals(end[1])) {
            if(start[0] > end[0]) {
                Integer[] temp = start;
                start = end;
                end = temp;
            }
            return new Room("room", start, new Bounds((end[0] - start[0]) + 1, 1), null);
        }
        return null;
    }

    public List<Room> buildSections() {
        List<Room> sections = new LinkedList<>();

        if(waypoints.length > 0) {
            sections.add(sectionCreator(from, waypoints[0]));
            for (int i = 0; i < waypoints.length - 1; i++) {
                sections.add(sectionCreator(waypoints[i], waypoints[i + 1]));
            }
            sections.add(sectionCreator(waypoints[waypoints.length - 1], to));
        } else {

            sections.add(new Room("room", from, new Bounds(to[0] - from[0] + 1, to[1] - from[1] + 1), null));
        }
        return sections;
    }



    public List<Game.Model.Room> populateSections() throws Exception {
        List<Game.Model.Room> sections = new LinkedList<>();
        Coordinate from = new Coordinate(this.from[0], this.from[1]);
        Coordinate to = new Coordinate(this.to[0], this.to[1]);
        List<Coordinate> wayPointList = new LinkedList<>();
        int j = 0;
        for(int i = 0; i < waypoints.length; i++) {
            wayPointList.add(new Coordinate(waypoints[i][j], waypoints[i][j+1]));
            System.out.println( waypoints[i][j] +"___" + waypoints[i][j+1]);
            j = 0;
        }

        if(wayPointList.size() == 0) {
            sections.add(createSection(from, to));
        } else{
            sections.add(createSection(from, wayPointList.get(0)));
            for(int i = 0; i < wayPointList.size() - 1; i++) {
                sections.add(createSection(wayPointList.get(i), wayPointList.get(i + 1)));
            }
            sections.add(createSection(wayPointList.get(wayPointList.size() - 1), to));
        }
        return sections;
    }

    private Game.Model.Room createSection(Coordinate from, Coordinate to) throws Exception {

        // horizontal hallway
        if(from.getX() == to.getX()) {
            int[][] tiles = new int[1][Math.abs(from.getY() - to.getY())];
            Arrays.stream(tiles).forEach(a -> Arrays.fill(a, 1));
            Coordinate origin = from.getY() > to.getY() ? to : from;
            return new Game.Model.Room(origin /** to is the origin since lesser point**/,
                    Math.abs(from.getY() - to.getY()), 1/** hallways are one width if horizontal**/,
                    Integer.MAX_VALUE, tiles);
        } else if (from.getY() == to.getY()) {
            int[][] tiles = new int[Math.abs(from.getX() - to.getX())][1];
            Arrays.stream(tiles).forEach(a -> Arrays.fill(a, 1));
            Coordinate origin = from.getX() > to.getX() ? to : from;
            return new Game.Model.Room(origin /** to is the origin since lesser point**/
                    , 1/** hallways are one width if horizontal**/,
                    Math.abs(from.getX() - to.getX()),
                    Integer.MAX_VALUE, tiles);
        }
        System.out.println(from.getX()+"+++"+from.getY());
        System.out.println(to.getX()+"++++"+to.getY());
        throw new Exception("uhh this should not be happening since from and to should be on the same line");
    }


    public boolean isPointInHallway(Integer[] point) {
        sections = buildSections();
        return sections.stream().anyMatch(i -> i.isPointWithinRoom(point));
    }

    public boolean isTraversable(Integer[] point) {
        // hallways are always traversable (so far)
        return true;
    }
}
