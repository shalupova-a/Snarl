package ManagerSrc;


import Game.Model.UI.GameViewType;
import Game.Model.UI.TextureType;
import asciiPanel.AsciiPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import Remote.Client;
import Game.View.ViewPanelFactory;
import Game.View.TileUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
//import jdk.vm.ci.meta.Local;
import org.json.*;

public class ClientView extends JFrame implements KeyListener {

    protected AsciiPanel gamePanel;
    protected AsciiPanel playerInfoPanel;
    protected AsciiPanel storyPanel;
    protected Integer[][] layout;
    protected List<Object> objects;
    protected List<ActorPosition> actors;
    private Client client;
    private Integer[] currentPlayerPosn;
    private final int CARDINAL_MOVES = 2;
    private TextureType texturePlayer = TextureType.PLAYER;
    ObjectMapper debugMapper = new ObjectMapper();
    public ClientView(Client client, String player) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        ViewPanelFactory viewPanelFactory = new ViewPanelFactory();
        gamePanel = viewPanelFactory.getAsciiPanel("GAME");
        storyPanel = viewPanelFactory.getAsciiPanel("STORY");
        playerInfoPanel = viewPanelFactory.getAsciiPanel("INVENTORY");
        this.setTitle(player + " view");
        this.client = client;
        this.layout = new Integer[5][5];
        this.actors = new ArrayList<ActorPosition>();
        this.objects = new ArrayList<Object>();
        this.currentPlayerPosn = new Integer[2];
    }

    public ClientView(Level level) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        ViewPanelFactory viewPanelFactory = new ViewPanelFactory();
        gamePanel = viewPanelFactory.getAsciiPanel("GAME");
        storyPanel = viewPanelFactory.getAsciiPanel("STORY");
        playerInfoPanel = viewPanelFactory.getAsciiPanel("INVENTORY");
        this.setTitle("Observer View");
        this.layout = new Integer[5][5];
        this.actors = new ArrayList<>();
        this.objects = new ArrayList<>();
        this.currentPlayerPosn = new Integer[2];
    }


    public void setLayout(Integer[][] layout) {
        this.layout = layout;
    }
    public void setObjects(List<Object> objects) {
        this.objects = objects;
    }

    public void setActors(List<ActorPosition> actors) {
        this.actors = actors;
    }

    public void setCurrentPlayerPosn(Integer[] position) {
        this.currentPlayerPosn = position;
    }

    public void welcomeScreen(int levelId) throws Exception {
        gamePanel.clear();
        storyPanel.clear();
        repaint();
        if(levelId == 1) {
            gamePanel.writeCenter(TextureType.BLOCK.getCodePoint() + "Welcome to Snarl!" + TextureType.BLOCK.getCodePoint(), 12, Color.cyan);
        }
        add(gamePanel);
        pack();
        // 13 is the 13 line in the panel
        gamePanel.writeCenter("Starting level " + levelId + " in 5 seconds...", 13);
        storyPanel.repaint();
        gamePanel.repaint();
        Thread.sleep(5000);
    }

    public void welcomeScreen(int levelId, int gameId) throws Exception {
        gamePanel.clear();
        storyPanel.clear();
        repaint();
        if(levelId == 1) {
            gamePanel.writeCenter(TextureType.BLOCK.getCodePoint() + "Welcome to Snarl!" + TextureType.BLOCK.getCodePoint(), 12, Color.cyan);
        }
        add(gamePanel);
        pack();

        gamePanel.writeCenter("Starting game " + gameId + " level " + levelId + " in 5 seconds", 13);
        storyPanel.repaint();
        gamePanel.repaint();
        Thread.sleep(5000);
    }


    public void beginGameScreen(String name) throws Exception {
        gamePanel.clear();
        repaint();
        add(playerInfoPanel, BorderLayout.EAST);
        add(storyPanel, BorderLayout.SOUTH);
        add(gamePanel, BorderLayout.WEST);
        initStoryPanel();

        storyPanel.writeCenter("Hello " + name + ", this is the color of your player.", 7, texturePlayer.getColor());
        print5X5Layout(layout);
        debugLayout(layout);
        placeItems(objects);
        placeActors(actors);
        pack();
        repaint();
        Thread.sleep(2000);
    }

    public void beginGameScreenObserver(String name, Level level, List<ActorPosition> players, List<ActorPosition> adversaries) {
        gamePanel.clear();
        storyPanel.clear();
        repaint();
        add(playerInfoPanel, BorderLayout.EAST);
        add(storyPanel, BorderLayout.SOUTH);
        add(gamePanel, BorderLayout.WEST);
        initStoryPanel();

        storyPanel.writeCenter("Hello " + name + ", you are in snarl game", 7);
        printHallways(level.getHallways());
        printRooms(level.getRooms());
        placeItems(level.getObjects());
        placeActors(players);
        placeActors(adversaries);
        pack();
        gamePanel.repaint();
        storyPanel.repaint();
    }

    public void endGameScreen(String message, JSONArray playerScoreList) throws Exception {
        gamePanel.clear();
        storyPanel.clear();
        repaint();
        gamePanel.writeCenter(message, 10, Color.green);

        for(int i = 0; i < playerScoreList.length(); i++) {
            JSONObject playerScore = playerScoreList.getJSONObject(i);
            updateStoryPanel(playerScore.get("name").toString() + " had " +
                    playerScore.get("exits") + " exits, " + playerScore.get("ejects") + " ejects, and "
                    + playerScore.get("keys") + " keys.", 5 + i * 2);
        }
        pack();
        repaint();
        Thread.sleep(5000);
    }

    public void endLevelScreen(String key, String exits, String ejects) throws Exception {
        gamePanel.clear();
        repaint();
        //gamePanel.writeCenter("End of level. Player scores:", 7, Color.green);
        updateStoryPanel("End of level.");
        gamePanel.writeCenter(key + " had key.", 7, Color.cyan);
        gamePanel.writeCenter(exits + " exited", 9, Color.cyan);
        gamePanel.writeCenter(ejects + " was ejected.", 11, Color.cyan);
        //add(gamePanel);
        pack();
        repaint();
    }

    public void updateGameScreen() {
        gamePanel.clear();
        print5X5Layout(layout);
        //debugLayout(layout);
        placeItems(objects);
        placeActors(actors);
        pack();
        gamePanel.repaint();
    }

    public void updateGameScreenObserver(Level level, List<ActorPosition> actors) {
        gamePanel.clear();
        printHallways(level.getHallways());
        printRooms(level.getRooms());
        placeItems(level.getObjects());
        placeActors(actors);
        pack();
        gamePanel.repaint();
    }

    private void debugLayout(Integer[][] layout) {
        try {
            System.out.println("DEEEBUDD");
            System.out.println(debugMapper.writeValueAsString(layout));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    /*
    public void gameMenuScreen(String username) {
        gamePanel.clear();
        gamePanel.writeCenter("Please enter your name", 12, Color.cyan);
        add(gamePanel);
        pack();
        // 13 is the 13 line in the panel
        gamePanel.writeCenter(username, 14);
        gamePanel.repaint();
    }


 */

    private void printRooms(List<Room> roomList) {
        ObjectMapper objectMapper = new ObjectMapper();
        for (Room room : roomList) {
            print2dArrayObserver(room.getLayout(), room.getOrigin());
        }
    }

    private void printSections(List<Game.Model.Room> rooms) {
        for (Game.Model.Room room : rooms) {
            print2dArrayObserver(room.getTiles(), new Integer[]{room.getPosition().getX(), room.getPosition().getY()});
        }
    }

    private void printHallways(List<ManagerSrc.Hallway> hallways) {
        List<Room> section = new LinkedList<>();
        for (Hallway hallway : hallways) {
            try {
                printSections(hallway.populateSections());
            } catch(Exception e) {
                e.printStackTrace();
                System.exit(0);
                System.out.println("hallway build exception");
            }
        }
    }

    private void placeItems(List<Object> items) {
        for (Object item : items) {
            if (item.getType().equals("key")) {
                writeTextureToGamePanel(item.getPosition()[1], item.getPosition()[0], TextureType.KEY);
            } else if (item.getType().equals("exit")) {
                writeTextureToGamePanel(item.getPosition()[1], item.getPosition()[0], TextureType.EXIT);
            }
        }
    }

    private void placeActors(List<ActorPosition> actors) {
        for (ActorPosition actor : actors) {
            try {
                System.out.println(debugMapper.writeValueAsString(actor));
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            System.out.println(actor.getPosition()[1]);
            System.out.println(actor.getPosition()[0]);
            if (actor.getType().equals(ActorType.ghost)) {
                writeTextureToGamePanel(actor.getPosition()[1], actor.getPosition()[0], TextureType.GHOST);
                continue;
            } else if (actor.getType().equals(ActorType.zombie)) {
                writeTextureToGamePanel(actor.getPosition()[1], actor.getPosition()[0], TextureType.ZOMBIE);
                continue;
            }

            if(!actor.isActorInPosition(this.currentPlayerPosn)) {
                writeTextureToGamePanel(actor.getPosition()[1], actor.getPosition()[0], TextureType.OTHER_PLAYER);
            } else {
                writeTextureToGamePanel(actor.getPosition()[1], actor.getPosition()[0], texturePlayer);
            }
        }
    }

    /**
     * Prints out a 2d array grid of valid chars
     * Instead of printing the whole game as a whole, this provides a small array which represents a room
     * Hallways can also be thought of as rooms with width or height set as 1 . so a hallway with 3 waypoints can be broken down as 3 rooms
     * <p>
     * Origin is the coordinate for the room's top left corner. for hallway section it can be the from point or waypoint
     *
     * @param grid: char[][]
     */

    private void print2dArray(Integer[][] grid) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                int tileInput = grid[i][j];
                int x = j + grid.length;
                int y = i + grid.length;
                int w = grid.length - 1;
                int h = grid[i].length - 1;

                // BLANK SPACE
                if (tileInput == TextureType.BLANK.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.BLANK);
                    // DOOR
                } else if (tileInput == TextureType.DOOR.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.DOOR);
                    // WALLS, we are checking corners so it has a nice smooth edge!
                } else if (tileInput == TextureType.BLOCK.getTileInput() && TileUtils.isBorder(i, j, grid.length - 1, grid[i].length - 1)) {
                    if (TileUtils.isLeftCorner(i, j)) {
                        writeTextureToGamePanel(x, y, TextureType.TOP_LEFT_CORNER);
                    } else if (TileUtils.isBottomLeftCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.BOTTOM_LEFT_CORNER);
                    } else if (TileUtils.isBottomRightCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.BOTTOM_RIGHT_CORNER);
                    } else if (TileUtils.isRightCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.TOP_RIGHT_CORNER);
                    } else {
                        // vertical border has vertical line and vice versa
                        if (TileUtils.isVerticalBorder(i, j, w, h)) {
                            writeTextureToGamePanel(x, y, TextureType.VERTICAL_WALL);
                        } else {
                            writeTextureToGamePanel(x, y, TextureType.HORIZONTAL_WALL);
                        }
                    }
                }
            }
        }
    }


    private void print2dArrayObserver(int[][] grid, Integer[] origin) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                int tileInput = grid[i][j];
                int x = j + origin[1];
                int y = i + origin[0];
                int w = grid.length - 1;
                int h = grid[i].length - 1;

                // BLANK SPACE
                if (tileInput == TextureType.BLANK.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.BLANK);
                    // DOOR
                } else if (tileInput == TextureType.DOOR.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.DOOR);
                    // WALLS, we are checking corners so it has a nice smooth edge!
                } else if (tileInput == TextureType.BLOCK.getTileInput() && TileUtils.isBorder(i, j, grid.length - 1, grid[i].length - 1)) {
                    if (TileUtils.isLeftCorner(i, j)) {
                        writeTextureToGamePanel(x, y, TextureType.TOP_LEFT_CORNER);
                    } else if (TileUtils.isBottomLeftCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.BOTTOM_LEFT_CORNER);
                    } else if (TileUtils.isBottomRightCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.BOTTOM_RIGHT_CORNER);
                    } else if (TileUtils.isRightCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.TOP_RIGHT_CORNER);
                    } else {
                        // vertical border has vertical line and vice versa
                        if (TileUtils.isVerticalBorder(i, j, w, h)) {
                            writeTextureToGamePanel(x, y, TextureType.VERTICAL_WALL);
                        } else {
                            writeTextureToGamePanel(x, y, TextureType.HORIZONTAL_WALL);
                        }
                    }
                } else {
                    System.out.println("Observer debug");
                }
            }
        }
    }

    /**
     * Simple printer that prints the 5 x 5 layout without worrying about walls
     * this is best for player view right now
     * @param grid
     */
    private void print5X5Layout(Integer[][] grid) {
        Integer[] origin = new Integer[2];

        origin[0] =  Math.max(0, currentPlayerPosn[0] - 2);
        origin[1] = Math.max(0, currentPlayerPosn[1] - 2);

        for (int i = 0; i < grid.length; i++) {
//            TODO Gotta fix this
            if (origin[0] == 0 && i == 1) {
                continue;
            }
            for (int j = 0; j < grid[i].length; j++) {
                int tileInput = grid[i][j];
                int x = j + origin[1];
                int y = i + origin[0];

              // BLANK SPACE
                if (tileInput == TextureType.BLANK.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.BLANK);
                    // DOOR
                } else if (tileInput == TextureType.DOOR.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.DOOR);
                    // WALLS, we are checking corners so it has a nice smooth edge!
                } else if (tileInput == TextureType.BLOCK.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.BLOCK);
                } else {
                    System.out.println("DEBUG " + tileInput);
                }
            }
        }
    }


    private void writeTextureToGamePanel(int x, int y, TextureType tt) {
        gamePanel.write(tt.getCodePoint(), x, y, tt.getColor());
    }

    private void writeTextureToStoryPanel(int x, int y, TextureType tt, Color color) {
        storyPanel.write(tt.getCodePoint(), x, y, color != null ? color : tt.getColor());
    }

    private void writeTextureToStoryPanel(int x, int y, TextureType tt) {
        storyPanel.write(tt.getCodePoint(), x, y, tt.getColor());
        storyPanel.repaint();
    }

    /** For the purpose of writing text to multiple lines of story panel**/
    public void updateStoryPanel(String text, int lineNum) throws Exception {
        storyPanel.writeCenter(text, lineNum);
        storyPanel.repaint();
    }

    /** public method to write stuff to story panel (panel at the bottom of screen) to give feedback to players and build the game story **/
    public void updateStoryPanel(String text) throws Exception {
        storyPanel.clear();
        storyPanel.writeCenter(text, 10);
        storyPanel.repaint();
    }


    /**
     * Creates the story panel which is the panel at the bottom that shows what the player should do, ask for moves etc...
     */
    private void initStoryPanel() {
        int W = storyPanel.getWidthInCharacters();
        int H = storyPanel.getHeightInCharacters();
        for (int i = 0; i < W; i++) {
            for (int j = 0; j < H; j++) {
                if (TileUtils.isBorder(i, j, W - 1, H - 1)) {
                    if (i == 0 || i == W - 1) {
                        if (TileUtils.isCornerTile(i, j, W - 1, H - 1)) {
                            writeTextureToStoryPanel(i, j, TextureType.BLOCK, Color.gray);
                            continue;
                        }
                        writeTextureToStoryPanel(i, j, TextureType.VERTICAL_WALL);
                    } else {
                        writeTextureToStoryPanel(i, j, TextureType.HORIZONTAL_WALL);
                    }
                }
            }
        }
    }

    public void repaint() {
        gamePanel.repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {

        int keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_RIGHT:
                movePlayerBy(0, 1);
                //clientView.updateStoryPanel("You moved right!");
                break;
            case KeyEvent.VK_LEFT:
                movePlayerBy(0, -1);
                //clientView.updateStoryPanel("You moved left!");
                break;
            case KeyEvent.VK_UP:
                movePlayerBy(-1, 0);
                //clientView.updateStoryPanel("You moved up!");
                break;
            case KeyEvent.VK_DOWN:
                movePlayerBy(1, 0);
                //clientView.updateStoryPanel("You moved down!");
                break;
            default:
                this.client.transitionScreens(keyCode, e.getKeyChar(), e.isActionKey(), this.currentPlayerPosn);
                break;
        }

    }

    private void movePlayerBy(int y, int x) {
        this.currentPlayerPosn = new Integer[]{this.currentPlayerPosn[0] + y, this.currentPlayerPosn[1] + x};
    }
}