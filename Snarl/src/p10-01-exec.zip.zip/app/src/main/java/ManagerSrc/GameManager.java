package ManagerSrc;

import java.util.*;
import java.util.stream.Collectors;

import Game.Model.Coordinate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GameManager {
    private State gameState;
    private static ObjectMapper objectMapper = new ObjectMapper();

    private RuleChecker ruleChecker;
    private ClientView clientView;

    public GameManager(State gameState) {
        this.gameState = gameState;
        this.ruleChecker = new RuleChecker(gameState);
        updatePlayerLocations();
        updateAdversaryLocations();
        this.gameState.populatePlayerList();
        this.gameState.populateAdversaryList(this.gameState.getLevel());

    }

    private void updatePlayerLocations() {
        List<ActorPosition> players =  this.gameState.getPlayers();
        for(ActorPosition player : players) {
            //System.out.println("updating location");
            player.setPosition(generateRandomLocation());
        }

    }

    private void updateAdversaryLocations() {
        List<ActorPosition> adversaries =  this.gameState.getAdversaries();
        for(ActorPosition adversary : adversaries) {
            //System.out.println("updating location");
            adversary.setPosition(generateRandomLocation());
        }
    }

    public State getState() {
        return this.gameState;
    }

    public void beckonAdversaryMove() {
        System.out.println("BECON MOVE");
        List<Integer[]> playerCoordinates = this.gameState.getPlayers().stream().map(adv -> adv.getPosition()).collect(Collectors.toList());
        List<Coordinate> playerCoords = playerCoordinates.stream().map(i -> new Coordinate(i[0], i[1])).collect(Collectors.toList());
        List<Coordinate> adversaryCoords = this.gameState.getAdversaryList().stream().map(Actor::getActorPosition).collect(Collectors.toList());
        for(Coordinate ad: adversaryCoords) {
            System.out.println(ad);
        }
        Map<String, Integer[]> oldPositionToNewPosition = new HashMap<>();
        System.out.println(this.gameState.getAdversaryList().size());
        System.out.println(this.gameState.getAdversaries().size());
        this.gameState.getAdversaryList().forEach(i -> {
            System.out.println("waht");
            try {
                String key = i.position.getX()+"__"+i.position.getY();
                Coordinate movingTo = i.makeMove(playerCoords ,adversaryCoords);
                oldPositionToNewPosition.put(key, new Integer[]{movingTo.getX(), movingTo.getY()});

            } catch (Exception e) {
                System.out.println("Exception for adversaryMove");
                e.printStackTrace();
            }
        });
        this.gameState.getAdversaries()
                .forEach(i -> {
                    i.setPosition(oldPositionToNewPosition.get(i.getPosition()[0] + "__" + i.getPosition()[1]));
                });
    }

    public Integer[] generateRandomLocation() {
        // TODO: allow location to be in hallway
        Random rand = new Random();
        Integer[] randLocation;

        List<Room> rooms = this.gameState.getLevel().getRooms();
        // need to change rand number generation since 0 was giving NPE
        int rand_room = rand.nextInt(rooms.size());
        Room room = rooms.get(rand_room);

        Integer[] origin = room.getOrigin();

        boolean foundTile = false;
        Integer[] point = new Integer[2];
        while (!foundTile) {
            Bounds roomBounds = room.getBounds();

            int x = rand.nextInt(roomBounds.getColumns() - 1);
            int y = rand.nextInt(roomBounds.getRows() - 1);
            point = new Integer[]{y + origin[0], x + origin[1]};

            try {
                if(room.isGlobalPointTraversable(point) && checkValidTile(point)) {
                    //TODO fix checkUnoccupied. not working currently bc players dont have position
                    //System.out.println("traversable");
                    //System.out.println(checkUnoccupied(point[0], point[1]));
                    System.out.println("found valid tile");
                    foundTile = true;

                }
            } catch (Exception e) {
                // we dont care
            }
        }
        //System.out.println(point[0]);
        //System.out.println(point[1]);
        return point;
    }

    private Coordinate generateRandomLocationCoord() {
        Integer[] coordArr = generateRandomLocation();
        return new Coordinate(coordArr[0], coordArr[1]);
    }


    public boolean isExitLocked() {
        return this.gameState.isExitLocked();
    }

    public boolean checkValidMove(Integer[] from, Integer[] to) {
        return checkCardinalMove(from[0], from[1], to[0], to[1]) && checkUnoccupied(to[0], to[1]) && checkValidTile(to);
    }

    private boolean checkCardinalMove(int fromX, int fromY, int toX, int toY) {

        return (Math.abs(fromX - toX) <= 1 && Math.abs(fromY - toY) <= 1)
                || (Math.abs(fromX - toX) == 2 && Math.abs(fromY - toY) == 0)
                || (Math.abs(fromX - toX) == 0 && Math.abs(fromY - toY) == 2);
    }



    private boolean checkUnoccupied(int x, int y) {
        // can't move to tile if there is another player (adversaries fine for now)
        //System.out.println("Checking unoccupied");

        for(ActorPosition player : this.gameState.getPlayers()) {
            Integer[] playerLocation = player.getPosition();

            if(x == playerLocation[0] && y == playerLocation[1]) {
                return false;
            }
        }
        return true;
    }

    private boolean checkValidTile(Integer[] point) {
        //System.out.println("checking valid tile");

        boolean isPointTraversableInRooms = gameState.getLevel().getRooms()
                .stream()
                .anyMatch(s -> s.isGlobalPointTraversable(point));
        boolean isPointTraversable = isPointTraversableInRooms || gameState.getLevel().getHallways().stream().anyMatch(s -> s.isPointInHallway(point));

        return isPointTraversable;
    }

    public boolean foundKey(Integer[] point) {

        boolean isLandedOnKey = gameState.getLevel().getObjects()
                .stream()
                .anyMatch(i -> i.isObjectOnPoint(point) && i.getType().equals("key"));

        if(isLandedOnKey) {
            this.gameState.setExitLocked(false);
        }

        return isLandedOnKey;
    }

    public void removeKey() {
        List<Object> objects = this.gameState.getLevel().getObjects();
        objects.removeIf(o -> o.getType().equals("key"));
    }

    public boolean exited(Integer[] point) {

        boolean isLandedOnExit = gameState.getLevel().getObjects()
                .stream()
                .anyMatch(i -> i.isObjectOnPoint(point) && i.getType().equals("exit"));

        return isLandedOnExit;
    }

    public boolean ejected(Integer[] point) {

        boolean isAdversaryInPoint = this.gameState.getAdversaries().stream().anyMatch(i -> i.isActorInPosition(point));

        return isAdversaryInPoint;
    }


    private List<Integer[]> getTraversableTiles(Integer[] position) {
        List<Integer[]> tiles = new ArrayList();
        for(int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                Integer[] tile = {position[0] + i, position[1] + j};
                tiles.add(tile);
            }
        }

        return tiles;
    }

    public int[][] getLayout(Integer[] position) {

        int[][] layout = new int[5][5];

        for(int i = -2; i <= 2; i++) {
            for(int j = -2; j <= 2; j++) {
                Integer[] tilePosn = {position[0] + i, position[1] + j};
                layout[i + 2][j + 2] = 0;

                for(Room room : this.gameState.getLevel().getRooms()) {

                    if(room.isPointWithinRoom(tilePosn)) {
                        int[] truePoint = {tilePosn[0] - room.getOrigin()[0], tilePosn[1] - room.getOrigin()[1]};
                        int tile = room.getLayout()[truePoint[0]][truePoint[1]];
                        layout[i + 2][j + 2] = tile;
                    }

                }
                for(Hallway hallway : this.gameState.getLevel().getHallways()) {
                    if(hallway.isPointInHallway(tilePosn) && layout[i + 2][j + 2] != 2) {
                        layout[i + 2][j + 2] = 1;
                    }
                }
            }
        }
        return layout;
    }

    public List<Object> getNearbyObjects(Integer[] position) {
        return getNearbyObjects(getTraversableTiles(position));
    }

    private List<Object> getNearbyObjects(List<Integer[]> traversableTiles) {
        Level level = this.gameState.getLevel();
        List<Object> objects = level.getObjects();

        List<Object> nearbyObjects = new ArrayList<>();

        for(Object object : objects) {
            Integer[] objectPosition = object.getPosition();
            for(Integer[] tile : traversableTiles) {
                if (objectPosition[0] == tile[0] && objectPosition[1] == tile[1]) {
                    nearbyObjects.add(object);
                }
            }
        }
        return nearbyObjects;
    }

    public List<ActorPosition> getNearbyActors(Integer[] position) {
        return getNearbyActors(getTraversableTiles(position), this.gameState.getActors());
    }

    private List<ActorPosition> getNearbyActors(List<Integer[]> traversableTiles, List<ActorPosition> players) {
        List<ActorPosition> actors = new ArrayList<>();
        actors.addAll(players);
        actors.addAll(this.gameState.getAdversaries());

        List<ActorPosition> nearbyActors = new ArrayList<>();

        for(ActorPosition actor : actors) {
            Integer[] actorPosition = actor.getPosition();
            for(Integer[] tile : traversableTiles) {
                if (actorPosition[0] == tile[0] && actorPosition[1] == tile[1]) {
                    nearbyActors.add(actor);
                }
            }
        }
        return nearbyActors;
    }

}