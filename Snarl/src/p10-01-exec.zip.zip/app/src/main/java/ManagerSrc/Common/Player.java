package ManagerSrc.Common;

public interface Player {
    void updatePlayerPosition(Integer[] playerPos) throws Exception;
    void promptPlayerMove();
}
