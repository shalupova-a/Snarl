package JsonMappers;

public class Input {
    private Level level;
    private Integer[] point;

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public Integer[] getPoint() {
        return point;
    }

    public void setPoint(Integer[] point) {
        this.point = point;
    }
}
