package JsonMappers;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.json.JSONPropertyName;

import java.util.List;

public class State {
    private String type;
    private Level level;
    private List<ActorPosition> actors;

    @JsonProperty("exit-locked")
    private boolean exitLocked;

    public List<ActorPosition> getActors() {
        return actors;
    }

    public void setActors(List<ActorPosition> actors) {
        this.actors = actors;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public boolean isExitLocked() {
        return exitLocked;
    }

    public void setExitLocked(boolean exitLocked) {
        this.exitLocked = exitLocked;
    }

}
