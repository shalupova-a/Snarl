package Game.Model;

// Represents an object in a Snarl game
public class Item {
	
	private Coordinate position;
	private final ItemType type;

	public Item(Coordinate position, ItemType type) {
		this.position = position;
		this.type = type;
	}

	/**
	 * Get position of item
	 * @return Coordinate
	 */
	public Coordinate getPosition() {
		return this.position;
	}

	/**
	 * Get type of item
	 * @return ItemType
	 */
	public ItemType getType() {
		return this.type;
	}

	public void setPosition(Coordinate position) {
		this.position = position;
	}
}
