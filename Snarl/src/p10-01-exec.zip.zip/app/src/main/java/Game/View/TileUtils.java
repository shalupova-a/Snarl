package Game.View;

public class TileUtils {

    public static boolean isCornerTile(int xCoord, int yCoord, int width, int height) {
        return isLeftCorner(xCoord, yCoord)
                || isRightCorner(xCoord, yCoord, width, height)
                || isBottomLeftCorner(xCoord, yCoord, width, height)
                || isBottomRightCorner(xCoord, yCoord, width, height);
    }

    public static boolean isBorder(int xCoord, int yCoord, int width, int height) {
        return isVerticalBorder(xCoord,yCoord,width, height) || isHorizontalBorder(xCoord, yCoord, width, height);
    }

    public static boolean isHorizontalBorder(int x, int y, int width, int height) {
        return x == 0 || x == width;
    }

    public static boolean isVerticalBorder(int x, int y, int width, int height) {
        return y == 0 || y == height;
    }


    public static boolean isLeftCorner(int x, int y) {
        return x == 0 && y == 0;
    }

    public static boolean isRightCorner(int x, int y,int width, int height) {
        return x == 0 && y == height;
    }

    public static boolean isBottomLeftCorner(int x, int y, int width, int height) {
        return x == width && y == 0;
    }

    public static boolean isBottomRightCorner(int x, int y, int width, int height) {
        return x == width && y == height;
    }
}
