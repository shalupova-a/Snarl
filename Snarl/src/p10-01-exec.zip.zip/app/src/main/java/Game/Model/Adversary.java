package Game.Model;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Map;

public class Adversary extends Actor {

    private Level initLevel;

    public Adversary(int id, ActorType actorType, Coordinate position) {
        super(id, actorType, position);
    }

    /**
     * Setter for initLevel
     * @param initLevel
     */
    public void setInitLevel(Level initLevel) {
        this.initLevel = initLevel;
    }

    /**
     * Determine tile adversary should move to
     * @param playerCoordinates coordinates of all actors in the game
     * @param adversaryCoordinates coordinates of all actors in the game
     * @return Coordinate
     * @throws Exception
     */
    public Coordinate makeMove(List<Coordinate> playerCoordinates, List<Coordinate> adversaryCoordinates) throws Exception {

        List<Coordinate> possibleMoves;
        List<Coordinate> validMoves = getTraversableTiles(1);

        if(this.actorType == ActorType.ZOMBIE) {
            possibleMoves = getZombieMoves(playerCoordinates, adversaryCoordinates, validMoves);
        } else if(this.actorType == ActorType.GHOST) {
            possibleMoves = getGhostMoves(adversaryCoordinates, validMoves);
        } else {
            throw new Exception(actorType + " is not a valid adversary.");
        }

        Coordinate to = moveTowardsPlayer(playerCoordinates, possibleMoves);

        if(to.checkEqualCoordinates(this.position)) {
            if(possibleMoves.size() > 0) {
                System.out.println(possibleMoves.size());
                for(Coordinate tile : possibleMoves) {
                    System.out.println(tile.getX() + ", " + tile.getY());
                }
                Random rand = new Random();
                int index = rand.nextInt(possibleMoves.size());

                to = possibleMoves.get(index);
                if(this.actorType == ActorType.GHOST) {
                    if(isWall(to)) {
                        System.out.println("We have a wall!");
                        to = findRandomTile();
                    }
                }
            }
        }

        setActorPosition(to);

        return to;
    }

    /**
     * Determines tiles numMoves cardinal moves away from adversary's position
     * @param numMoves
     * @return List<Coordinate>
     */
    private List<Coordinate> getTraversableTiles(int numMoves) {

        List<Coordinate> traversableTiles = new ArrayList<>();

        for(int i = 0; i < numMoves + 1; i++) {
            for(int j = 0; j < numMoves + 1; j++) {
                if (!(i == 0 && j == 0)) {
                    if (i == 0) {
                        traversableTiles.add(new Coordinate(this.position.getX(), this.position.getY() + j, this.position.getRoomId()));
                        traversableTiles.add(new Coordinate(this.position.getX(), this.position.getY() - j, this.position.getRoomId()));
                    } else if (j == 0) {
                        traversableTiles.add(new Coordinate(this.position.getX() - i, this.position.getY(), this.position.getRoomId()));
                        traversableTiles.add(new Coordinate(this.position.getX() + i, this.position.getY(), this.position.getRoomId()));
                    } else {
                        traversableTiles.add(new Coordinate(this.position.getX() - i, this.position.getY() - j, this.position.getRoomId()));
                        traversableTiles.add(new Coordinate(this.position.getX() + i, this.position.getY() - j, this.position.getRoomId()));
                        traversableTiles.add(new Coordinate(this.position.getX() + i, this.position.getY() + j, this.position.getRoomId()));
                        traversableTiles.add(new Coordinate(this.position.getX() - i, this.position.getY() + j, this.position.getRoomId()));
                    }
                }
            }
        }


        return traversableTiles;
    }

    /**
     * Returns a list of tiles
     * @param playerCoordinates
     * @param adversaryCoordinates
     * @param traversableTiles
     * @return
     */
    private List<Coordinate> getZombieMoves(List<Coordinate> playerCoordinates, List<Coordinate> adversaryCoordinates, List<Coordinate> traversableTiles) {

        List<Coordinate> tiles = new ArrayList<>(traversableTiles);
        // remove tiles that have adversary or is a door
        for(Coordinate tile : tiles) {
            for(Coordinate adversaryCoordinate : adversaryCoordinates) {
                if(adversaryCoordinate.checkEqualCoordinates(tile)) {
                    traversableTiles.remove(tile);
                }
            }
            if(isDoor(tile) || outOfBounds(tile)) {
                traversableTiles.remove(tile);
            }
        }

        return traversableTiles;
    }

    /**
     * Checks if given Coordinate corresponds to a door
     * @param tile
     * @return boolean
     */
    private boolean isDoor(Coordinate tile) {
        List<Room> rooms = initLevel.getRooms();

        for(Room room : rooms) {
            if(room.isDoor(tile)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks that tile is within bounds of a room
     * @param tile
     * @return boolean
     */
    private boolean outOfBounds(Coordinate tile) {
        try {
            this.initLevel.findRoom(tile);
        } catch(Exception e) {
            return true;
        }

        return false;
    }

    /**
     * Determines best tiles the Ghost can move to
     * @param playerCoordinates
     * @param traversableTiles
     * @return List<Coordinate>
     */
    private List<Coordinate> getGhostMoves(List<Coordinate> playerCoordinates, List<Coordinate> traversableTiles) {

        List<Coordinate> tiles = new ArrayList<>(traversableTiles);
        for(Coordinate tile : tiles) {
            try {
                this.initLevel.findRoom(tile);
            } catch(Exception e) {
                if(!isWall(tile)) {
                    traversableTiles.remove(tile);
                }
            }
        }

        return traversableTiles;
    }

    /**
     * Detemine is the tile is a wall in a Room
     * @param tile
     * @return boolean
     */
    private boolean isWall(Coordinate tile) {

        List<Room> rooms = this.initLevel.getRooms();

        for(Room room : rooms) {
            Coordinate roomPosn = room.getPosition();
            if((tile.getX() == roomPosn.getX() || tile.getX() == roomPosn.getX() + room.getWidth() - 1) &&
                    (tile.getY() == roomPosn.getY() || tile.getY() == roomPosn.getY() + room.getHeight() - 1)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get tile of closest player
     * @param playerCoordinates
     * @return
     */
    private Coordinate getClosestTile(List<Coordinate> coordinates, Coordinate posn) {
        int minDistance = Integer.MAX_VALUE;
        Coordinate closestTile = this.position;

        for(Coordinate tile : coordinates) {
            if(tile.getRoomId() == posn.getRoomId()) {
                int manhattanDist = Math.abs(tile.getX() - posn.getX())
                        + Math.abs(tile.getY() - posn.getY());
                if(manhattanDist < minDistance) {
                    minDistance = manhattanDist;
                    closestTile = tile;
                }
            }
        }

        return closestTile;
    }

    /**
     * Find traversable tile closest to player
     * @param playerCoordinates
     * @param traversableTiles
     * @return Coordinate
     */
    private Coordinate moveTowardsPlayer(List<Coordinate> playerCoordinates, List<Coordinate> traversableTiles) {
        Coordinate closestTile = getClosestTile(playerCoordinates, this.position);
        Coordinate to = this.position;

        if(!closestTile.checkEqualCoordinates(this.position)) {
            to = getClosestTile(traversableTiles, closestTile);
        }
        return to;
    }

    /**
     * Find random tile in a random room
     * @return Coordinate
     */
    private Coordinate findRandomTile() {
        Random rand = new Random();
        Coordinate randLocation;

        List<Room> rooms = this.initLevel.getRooms();
        Room nextRoom;
        // ensures we get a different room if there are multiple rooms
        if(rooms.size() > 1) {
            int rand_room = this.position.getRoomId();
            while (rand_room == this.position.getRoomId()) {
                rand_room = rand.nextInt(rooms.size());
            }
            nextRoom = rooms.get(rand_room); // random room
        } else {
            nextRoom = rooms.get(this.position.getRoomId());
        }

        Coordinate roomPosn = nextRoom.getPosition();

        int rand_x = rand.nextInt(nextRoom.getWidth() - 1) + roomPosn.getX();
        int rand_y = rand.nextInt(nextRoom.getHeight() - 1) + roomPosn.getY();
        
        return new Coordinate(rand_x, rand_y, nextRoom.getRoomId());
    }
}