package Game.Controller.Entity;

public enum MessageType {
    INITIALIZE, START, DISPLAY, STATUS, QUERY, ACTION
}