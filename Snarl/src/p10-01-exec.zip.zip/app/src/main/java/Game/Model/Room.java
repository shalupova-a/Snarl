package Game.Model;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Collections;

public class Room {

	private Coordinate position;
	private int width;
	private int height;
	private int[][] tiles;
	private int roomId;
	private static final List<Integer> ACCEPTABLE_INTS = new ArrayList<Integer>(Arrays.asList(0, 1, 2));

	public Room(Coordinate position, int width, int height, int roomId, int[][] tiles) throws Exception {
		this.position = position;
		checkDimensions(width, height);
		checkRoomId(roomId);
		checkTiles(tiles);
	}

	/**
	 * Get room position
	 * @return Coordinate
	 */
	public Coordinate getPosition() {
		return this.position;
	}

	/**
	 * Get room height
	 * @return int
	 */
	public int getHeight() {
		return this.height;
	}

	/**
	 * Get room width
	 * @return int
	 */
	public int getWidth() {
		return this.width;
	}

	/**
	 * Get room tiles
	 * @return int[][]
	 */
	public int[][] getTiles() {
		return this.tiles;
	}

	/**
	 * Get room id
	 * @return int
	 */
	public int getRoomId() {
		return this.roomId;
	}

	/**
	 * Check that a Coordinate is within a room
	 * @param point: Coordinate
	 * @return boolean
	 */
	public boolean withinBounds(Coordinate point) {

//		System.out.println("DEBUG: Checking within bounds in Room " + getRoomId());
		//System.out.println(inRoom(point));
		//System.out.println(isDoor(point));
		return inRoom(point) || isDoor(point);
	}

	/**
	 * Check that a Coordinate is within a room and not a wall
	 * @param point: Coordinate
	 * @return boolean
	 */
	private boolean inRoom(Coordinate point) {
		return (point.getX() > position.getX() && point.getX() < position.getX() + width - 1 &&
				point.getY() > position.getY() && point.getY() < position.getY() + height - 1);
	}

	/**
	 * Check if a Coordinate is a door
	 * @param point: Coordinate
	 * @return boolean
	 */
	public boolean isDoor(Coordinate point) {
		//System.out.println("DEBUG: Checking if tile is door in Room");

		if(point.getX() >= position.getX() && point.getX() < position.getX() + width &&
				point.getY() >= position.getY() && point.getY() < position.getY() + height) {
			//System.out.println("checking is door");
			return tiles[point.getY() - position.getY()][point.getX() - position.getX()] == 2;
		}

		return false;
	}

	/**
	 * Check that dimensions of room is greater than 0 and initialize
	 * @param width: int
	 * @param height: int
	 * @throws Exception
	 */
	private void checkDimensions(int width, int height) throws Exception{
		if(width < 1 || height < 1) {
			throw new Exception("Dimensions of a room must be greater than 0.");
		}
		this.width = width;
		this.height = height;
	}

	/**
	 * Check that roomId and roomId of position Coordinate match and initialize
	 * @param roomId: int
	 * @throws Exception
	 */
	private void checkRoomId(int roomId) throws Exception{
		// CLEANUP : dont need this check for now
		if(roomId != this.position.getRoomId() && false) {
			throw new Exception("Room ID must match room Id in position field.");
		}
		this.roomId = roomId;
	}

	/**
	 * Check that tiles have correct correct dimensions and values
	 * @param tiles: int[][]
	 * @throws Exception
	 */
	private void checkTiles(int[][] tiles) throws Exception {
		if(tiles.length != this.height) {
			throw new Exception("Incorrect number of rows: " + tiles.length + " in tiles 2d array for room: " + this.roomId);
		}

		for(int i = 0; i < tiles.length; i++) {
			if(tiles[i].length != this.width) {
				throw new Exception("Incorrect number of columns in tiles 2d array.");
			}
			for(int j = 0; j < tiles[i].length; j++) {
				if(!ACCEPTABLE_INTS.contains(tiles[i][j])) {
					throw new Exception(tiles[i][j] + " is not a recognized representation of a tile for the tiles 2d array.");
				}
			}
		}

		this.tiles = tiles;
	}
}
