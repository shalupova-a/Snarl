package Game.Controller;

import Game.Controller.Entity.MessageType;
import Game.CmdLineOption;
import Game.Model.Level;
import Game.View.AsciiView;
import Player.LocalPlayer;
import org.json.JSONObject;

import java.io.IOException;
import java.util.*;

public class PlayerClient {
    private Scanner scanner = new Scanner(System.in);
    private GameManager manager;
    private List<Integer> players;
    private List<LocalPlayer> localPlayers;
    private List<Integer> enemies;

    public PlayerClient() throws Exception {
        manager = new GameManager();
    }

    public PlayerClient(Level level,boolean isObserver) throws Exception {
        manager = new GameManager(level, isObserver);
    }

    public void init(CmdLineOption userOptions, Level level) throws Exception {
        // init the game manager
        PlayerClient client = new PlayerClient(level, userOptions.getIsObserverMode());

        // do start screen

        client.startConnection(userOptions.getPlayers());
        client.manager.start();

        while (client.manager.stillPlaying()) {

            for (LocalPlayer localPlayer : client.localPlayers) {
                if (client.manager.isAlive(localPlayer.getId())) {
                    localPlayer.promptPlayerMove();
                } else {
                    System.out.println("Player " + localPlayer.getId() + " is dead and just observing the game.");
                }
            }
        }

        if (client.manager.getWinStatus()) {
            client.manager.stop("A player has reached the exit and you have won!");
        } else {
            client.manager.stop("Sorry you lost!");
        }
    }

    /**
     * Create players and enemies
     *
     * @throws Exception
     */
    /*
    public void startConnection() throws Exception {
        int id1 = manager.createPlayer();
        int id2 = manager.createPlayer();
        localPlayers = new LinkedList<>();
        players = new ArrayList<>(Arrays.asList(id1, id2));
        for (int pid : players) {
            localPlayers.add(new LocalPlayer(pid, pid + ""));
        }
        int id3 = manager.createEnemy();
        enemies = new ArrayList<>(Arrays.asList(id3));
    }*/

    public void startConnection(int numPlayers) throws Exception {
        Scanner scan = new Scanner(System.in);

        players = new ArrayList<>();

        localPlayers = new LinkedList<>();
        for (int pid = 0; pid < numPlayers; pid++) {
            System.out.println("Enter name for player-" + pid);
            String name = scan.next();
            localPlayers.add(new LocalPlayer(pid, name));
            players.add(manager.createPlayer(name));
        }

//        int id3 = manager.createEnemy();
//        enemies = new ArrayList<>(Arrays.asList(id3));
    }

    public void startAsciiConnection(int numPlayers)  {

    }

    /**
     * Prompt user for move and handle user input
     *
     * @param id: player id
     */
    private void promptMove(int id) {

        boolean validInput = false;

        while (!validInput) {

            System.out.println("-Player " + id + " move-");
            System.out.println("Please enter number for action:\n\t1. Move to a different tile. \n\t2. Stay put\n\t3. Exit game");
            try {
                int input = scanner.nextInt();
                switch (input) {
                    case 1:
                        System.out.println("Note that you can only move 2 cardinal tiles at a time to an unoccupied tile.");
                        System.out.println("\tEnter x coordinate of destination:");
                        int xCoord = scanner.nextInt();
                        System.out.println("\tEnter y coordinate of destination:");
                        int yCoord = scanner.nextInt();
                        manager.handlePlayerMove(xCoord, yCoord, id);
                        validInput = true;
                        break;
                    case 2:
                        System.out.println("Staying put!");
                        validInput = true;
                        break;
                    case 3:
                        System.out.println("Exiting game.");
                        manager.expelPlayer(id);
                        validInput = true;
                        break;
                    default:
                        System.out.println("Invalid option. Try again.");
                        break;
                }

            } catch (Exception e) {
                System.out.println("Invalid input. Try again\n" + e);
            }
        }
    }

    public GameManager getManager() {
        return this.manager;
    }

    private void stopConnection() throws IOException {
        //stub
    }

    private String sendMessage(String msg) throws IOException {
        //stub
        return "";
    }

    private JSONObject createJSONObject(MessageType type, String message) {
        //stub
        JSONObject jsonObj = new JSONObject();

        return jsonObj;
    }
}