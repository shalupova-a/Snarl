package Game.View;

import Game.Model.*;

import java.util.*;

public class GameView {

    private HashMap<Room, Coordinate> roomPosns;
    private char[][] asciiLayout;
    private Level level;
    private List<Room> rooms;
    private List<Hallway> hallways;
    private List<Item> items;
    private Coordinate levelKey;
    private Coordinate levelExit;
    private static final Set<Character> ACCEPTABLE_CHARS =
            new HashSet<>(Arrays.asList('+', 'X', '_', ']', 'E', 'K', '1', '2', '3', '4', 'A'));

    public GameView(Level level) {
        this.level = level;
        this.rooms = level.getRooms();
        this.hallways = level.getHallways();
        this.items = level.getItems();
        extractItems(items);
        this.roomPosns = new HashMap<>();
        addToMapPosns();
        setAsciiLayout();
    }

    /**
     * Update the level
     *
     * @param level: Level
     */
    public void updateLevel(Level level) {
        this.level = level;
        this.rooms = level.getRooms();
        this.hallways = level.getHallways();
        this.items = level.getItems();
        extractItems(items);
        this.roomPosns = new HashMap<>();
        addToMapPosns();
        setAsciiLayout();

        //System.out.println("DEBUG Items");
        //System.out.println(this.items.size());
    }

    /**
     * Sets levelKey and levelExit
     *
     * @param items: List<Item>
     */
    private void extractItems(List<Item> items) {

        this.levelKey = null;
        this.levelExit = null;

        for (Item item : items) {
            if (item.getType() == ItemType.EXIT) {
                this.levelExit = item.getPosition();
            }

            if (item.getType() == ItemType.KEY) {
                this.levelKey = item.getPosition();
            }
        }
    }

    /**
     * Adds rooms to roomPosns map
     */
    private void addToMapPosns() {
        for (Room room : this.rooms) {
            roomPosns.put(room, room.getPosition());
        }
    }

    /**
     * Set the dimensions of the ascii level
     */
    private void setAsciiLayout() {
        int levelX = 0;
        int levelY = 0;

        for (Room room : this.rooms) {
            Coordinate roomPosn = room.getPosition();
            if (levelX < roomPosn.getX()) {
                levelX = roomPosn.getX() - levelX;
            }

            if (levelY < roomPosn.getY()) {
                levelY = roomPosn.getY() - levelY;
            }

            levelX += room.getWidth();
            levelY += room.getHeight();

        }
        for (Hallway hallway : this.hallways) {
            Coordinate hallwayPosn = hallway.getFrom();
            levelX += hallway.getLength() + hallwayPosn.getX();
            levelY += hallway.getLength() + hallwayPosn.getY();
        }

        asciiLayout = new char[levelX][levelY];
    }

    public char[][] getAsciiLayout() {
        return this.asciiLayout;
    }

    /**
     * Print out a view based on the given location and tiles
     *
     * @param location: Coordinate
     * @param tiles:    List<Coordinate>
     */
    public void renderPlayerView(Coordinate location, List<Coordinate> tiles) {
        System.out.println("\nCurrent location: (" + location.getX() + ", " + location.getY() + ")\n");
        for (int i = 0; i < asciiLayout.length; i++) {
            StringBuilder stringBuffer = new StringBuilder();
            for (int j = 0; j < asciiLayout[i].length; j++) {
                if (ACCEPTABLE_CHARS.contains(asciiLayout[i][j]) && isTraversable(j, i, tiles)) {
                    stringBuffer.append(asciiLayout[i][j]).append(" ");
                } else {
                    stringBuffer.append("  ");
                }
            }
            String toPrint = stringBuffer.toString();
            if (toPrint.trim().length() != 0) {
                System.out.println(toPrint);
//                System.out.println();
            }
        }
    }

    // check if we should print this tile in player view

    /**
     * Check that an x and y coordinate are a Coordinate in tiles
     *
     * @param x:     int
     * @param y:     int
     * @param tiles: List<Coordinate>
     * @return boolean
     */
    private boolean isTraversable(int x, int y, List<Coordinate> tiles) {

        for (Coordinate tile : tiles) {
            if (tile.getX() == x && tile.getY() == y) {
                return true;
            }
        }

        return false;
    }

    /**
     * Create ascii representation of current level
     *
     * @param players: List<Player>
     * @param enemies: List<Adversary>
     */
    public void renderLevel(List<Player> players, List<Adversary> enemies) {

        for (Map.Entry mapElement : this.roomPosns.entrySet()) {
            Room room = (Room) mapElement.getKey();
            Coordinate roomPosn = (Coordinate) mapElement.getValue();

            // draw all the Hallways connected to this Room
            for (Hallway hallway : this.hallways) {
                if (withinRoom(hallway.getFrom(), roomPosn, room.getHeight(), room.getWidth())) {
                    drawHallway(hallway.getTiles(), hallway.getLength(), hallway.getFrom());
                }
            }

            drawRoom(room.getWidth(), room.getHeight(), room.getTiles(), roomPosn);
        }

        // add Players to asciiLayout
        for (Player player : players) {
            Coordinate playerPosn = player.getActorPosition();
            asciiLayout[playerPosn.getY()][playerPosn.getX()] = Character.forDigit(player.getActorId(), 10);
        }

        // add Enemies to asciiLayout
        for (Adversary enemy : enemies) {
            Coordinate enemyPosn = enemy.getActorPosition();
            asciiLayout[enemyPosn.getY()][enemyPosn.getX()] = 'A';
        }

        // add level exit to asciiLayout
        asciiLayout[levelExit.getY()][levelExit.getX()] = 'E';

        // add key to asciiLayout
        if (levelKey != null) {
            asciiLayout[levelKey.getY()][levelKey.getX()] = 'K';
        }
    }

    /**
     * Determine if a Hallway starts from a Room
     *
     * @param hallwayFrom: Coordinate
     * @param roomPosn:    Coordinate
     * @param height:      int
     * @param width:       int
     * @return boolean
     */
    private boolean withinRoom(Coordinate hallwayFrom, Coordinate roomPosn, int height, int width) {
        return hallwayFrom.getX() >= roomPosn.getX() && hallwayFrom.getX() <= roomPosn.getX() + width - 1 &&
                hallwayFrom.getY() >= roomPosn.getY() && hallwayFrom.getY() <= roomPosn.getY() + height - 1;
    }

    /**
     * Convert a Room's tiles to char[][] and add to asciiLayout of level
     *
     * @param width:  int room width
     * @param height: int room height
     * @param tiles:  int[][] room tiles
     * @param posn:   Coordinate room posn
     */
    private void drawRoom(int width, int height, int[][] tiles, Coordinate posn) {
        char[][] roomTiles = new char[height][width];

        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                if (tiles[i][j] == 0) {
                    roomTiles[i][j] = 'X';
                } else if (tiles[i][j] == 1) {
                    roomTiles[i][j] = '_';
                } else {
                    roomTiles[i][j] = ']';
                }
            }
        }

        for (int i = 0; i < roomTiles.length; i++) {
            for (int j = 0; j < roomTiles[i].length; j++) {
                asciiLayout[i + posn.getY()][j + posn.getX()] = roomTiles[i][j];
            }
        }
    }


    // let's draw the hallways!

    /**
     * Adds hallway to asciiLayout of level
     *
     * @param room:      Room hallway starts at
     * @param length:    int length of hallway
     * @param from:      Coordinate hallway starts at
     * @param to:        Coordinate hallway ends at
     * @param waypoints: List<Coordinate> hallway waypoints
     */
    private void drawHallway(int[][] tiles, int length, Coordinate from) {

        char[][] hallwayTiles = new char[length + 1][length + 1];

        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                if (tiles[i][j] == 1) {
                    hallwayTiles[i][j] = '_';
                } else if (tiles[i][j] == -1) {
                    hallwayTiles[i][j] = '+';
                } else {
                    //hallwayTiles[i][j] = 'X';
                }
            }
        }

        for (int i = 0; i < hallwayTiles.length; i++) {
            for (int j = 0; j < hallwayTiles[i].length; j++) {
                asciiLayout[i + from.getY()][j + from.getX()] = hallwayTiles[i][j];
            }
        }
    }

    /**
     * Prints out a 2d array grid of valid chars
     *
     * @param grid: char[][]
     */
    private void print2dArray(char[][] grid) {
        for (int i = 0; i < grid.length; i++) {
            StringBuilder stringBuilder = new StringBuilder();

            for (int j = 0; j < grid[i].length; j++) {
                if (ACCEPTABLE_CHARS.contains(grid[i][j])) {
                    stringBuilder.append(grid[i][j]).append(" ");
                } else {
                    stringBuilder.append("  ");
                }
            }

            String toPrint = stringBuilder.toString();
            if (toPrint.trim().length() != 0) {
                System.out.println(toPrint);
//                System.out.println();
            }
        }
    }

    /**
     * Prints out ascii representation of level
     *
     * @param players: List<Player>
     * @param enemies  List<Adversary>
     */
    public void printLevel(List<Player> players, List<Adversary> enemies) {

        renderLevel(players, enemies);
        print2dArray(asciiLayout);
    }
}