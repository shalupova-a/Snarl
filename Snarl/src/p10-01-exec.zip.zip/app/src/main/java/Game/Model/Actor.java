package Game.Model;

public abstract class Actor {

    protected int actorId;
    protected Coordinate position;
    protected ActorType actorType;
    protected int hitPoints;
    protected int attack;
    protected int defense;
    protected int modifier;

    public Actor(int actorId, ActorType actorType, Coordinate position) {
        this.actorId = actorId;
        this.actorType = actorType;
        this.position = position;
    }

    public Actor(int actorId, Coordinate position, ActorType actorType, int hitPoints, int attack, int defense, int modifier) {
        this.actorId = actorId;
        this.position = position;
        this.actorType = actorType;
        this.hitPoints = hitPoints;
        this.attack = attack;
        this.defense = defense;
        this.modifier = modifier;
    }

    /**
     * Get player id
     * @return int
     */
    public int getActorId() {
        return this.actorId;
    }

    /**
     * Get player position
     * @return Coordinate
     */
    public Coordinate getActorPosition() {
        return position;
    }

    /**
     * Get actor type
     * @return ActorType
     */
    public ActorType getActorType() {
        return actorType;
    }

    /**
     * Change player's location to given coordinate
     * @param coordinate: Coordinate
     */
    public void setActorPosition(Coordinate coordinate) {
        this.position = new Coordinate(coordinate.getX(), coordinate.getY());
    }

    public int getHitPoints() {
        return hitPoints;
    }

    public void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public int getModifier() {
        return modifier;
    }

    public void setModifier(int modifier) {
        this.modifier = modifier;
    }
}