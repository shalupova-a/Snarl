package Game.Model;

// Represents an x, y coordinate in a Snarl game. Also includes roomId of which this coordinate belongs to.
public class Coordinate {
	private int x;
	private int y;
	private int roomId;

	public Coordinate(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Coordinate(int x, int y, int roomId) {
		this(x, y);	
		this.roomId = roomId;
	}

	/**
	 * Get x coordinate
	 * @return int
	 */
	public int getX() {
		return this.x;
	}

	/**
	 * Get y coordinate
	 * @return int
	 */
	public int getY() {
		return this.y;
	}

	/**
	 * Get room id of Coordinate
	 * @return int
	 */
	public int getRoomId() {
		return this.roomId;
	}

	public boolean checkEqualCoordinates(Coordinate coordinate) {
		return coordinate.getX() == this.x && coordinate.getY() == this.y && coordinate.getRoomId() == this.roomId;
	}

	@Override
	public String toString() {
		return "Coordinate{" +
				"x=" + x +
				", y=" + y +
				'}';
	}
}
