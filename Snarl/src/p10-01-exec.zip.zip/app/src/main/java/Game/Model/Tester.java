package Game.Model;

import Game.View.GameView;
import java.util.*;

// a few examples of how our levels should render
public class Tester {

	public static void main(String[] args) throws Exception{
		/*
		System.out.println("Test 1");
		test2RoomsH1Hallway();
		System.out.println("Test 2");	
		test2RoomsV1Hallway();
		System.out.println("Test 3");
		test2RoomsVWaypoints();
		System.out.println("Test 4");
		test2RoomsHWaypoints();
		System.out.println("Test 5");
		test3RoomsHWaypoints();
		*/
		System.out.println("Test 6");
		test2RoomsH2Waypoints();
		System.out.println("Test 7");
		test2RoomsV2Waypoints();

		System.out.println("Test 8");
		testRoom2Hallways();
	}	
	
	// two rooms side by side horizontally with a horizontal hallway connecting
	public static void test2RoomsH1Hallway() throws Exception {
		/* X X X X X X X             X X X * X X
 		*  X _ _ _ _ _ X X X X X X X X _ _ _ _ X
 		*  X _ _ _ _ _ ] - - - - - - ] _ _ _ _ X
 		*  X _ _ _ _ _ X X X X X X X X _ _ _ _ X
 		*  X _ _ _ _ _ X             X _ _ _ _ X
 		*  X _ _ _ _ _ X             X _ _ _ _ X
 		*  X X X X X X X             X _ _ _ _ X
 		*                            X _ _ _ _ X
 		*                            X X X X X X
  		*/

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0, 0, 0},
				{0, 1, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 1, 2},
				{0, 1, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 1, 0},
				{0, 0, 0, 0, 0, 0, 0} };

		int[][] tilesRoom2 = { {0, 0, 0, -1, 0, 0},
				{0, 1, 1, 1, 1, 0},
				{2, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 0, 0, 0, 0, 0} };

		Room room1 = new Room(new Coordinate(0, 0, 0), 7, 7, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(13, 0, 1), 6, 9, 1, tilesRoom2);
		Hallway hallway = new Hallway(100, new Coordinate(6, 2, 0), new Coordinate(13, 2, 1));

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		hallways.add(hallway);
		Coordinate exitCoord = new Coordinate(3, 0, 1);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}

	// two rooms side by side vertically with a vertical hallway connecting
	public static void test2RoomsV1Hallway() throws Exception {
		/*  X X X X X X X
		 *  X _ _ _ _ _ X
		 *  X _ _ _ _ _ X
		 *  X _ _ _ _ _ X
		 *  X X X ] X X X
		 *        |
		 *        |
		 *        |
		 *        |
		 *        |
		 *        |
		 *  * X X ] X X
		 *  X _ _ _ _ X
		 *  X _ _ _ _ X
		 *  X _ _ _ _ X
		 *  X _ _ _ _ X
		 *  X X X X X X
		 */

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0, 0, 0},
				{0, 1, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 1, 0},
				{0, 0, 0, 2, 0, 0, 0} };

		int[][] tilesRoom2 = { {-1, 0, 0, 2, 0, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 0, 0, 0, 0, 0} };

		Room room1 = new Room(new Coordinate(0, 0, 0), 7, 5, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(0, 11, 1), 6, 6, 1, tilesRoom2);
		Hallway hallway = new Hallway(100, new Coordinate(3, 4, 0), new Coordinate(3, 11, 1));

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		hallways.add(hallway);
		Coordinate exitCoord = new Coordinate(0, 0, 1);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}

	// two diagonal rooms connected by a vertical hallway with a waypoint
	public static void test2RoomsVWaypoints() throws Exception {
		/*  X X X X X
		 *  X _ _ _ X
		 *  X _ _ _ X
		 *  X _ _ _ X
		 *  X X X ] X
		 *        |
		 *        |
		 *        + _ _ _ _ _ ] X X X
		 *                    X _ _ X
		 *                    X _ _ *
		 *                    X _ _ X
		 *                    X X X X
		 */

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0,},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 0},
				{0, 0, 0, 2, 0} };

		int[][] tilesRoom2 = { {2, 0, 0, 0},
				{0, 1, 1, 0},
				{0, 1, 1, -1},
				{0, 1, 1, 0},
				{0, 0, 0, 0,} };

		Room room1 = new Room(new Coordinate(0, 0, 0), 5, 5, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(9, 7, 1), 4, 5, 1, tilesRoom2);
		List<Coordinate> waypoints = new ArrayList<>(Arrays.asList(new Coordinate(3, 7, 100)));
		Hallway hallway = new Hallway(100, new Coordinate(3, 4, 0), new Coordinate(9, 7, 1), waypoints);

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		hallways.add(hallway);
		Coordinate exitCoord = new Coordinate(12, 9, 1);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}

	// two diagonal rooms connected by a vertical hallway with 2 waypoints
	public static void test2RoomsV2Waypoints() throws Exception {
		/*  X X X X X
		 *  X _ _ _ X
		 *  X _ _ _ X
		 *  X _ _ _ X
		 *  X X X ] X
		 *        |
		 *        |
		 *        + _ _ _ +
		 *                _
		 *                _
		 *            X X ] X
		 * 		      X _ _ *
		 *            X _ _ X
		 *            X X X X
		 */

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0,},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 0},
				{0, 0, 0, 2, 0} };

		int[][] tilesRoom2 = { {0, 0, 2, 0},
				{0, 1, 1, -1},
				{0, 1, 1, 0},
				{0, 0, 0, 0,} };

		Room room1 = new Room(new Coordinate(0, 0, 0), 5, 5, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(5, 10, 1), 4, 4, 1, tilesRoom2);
		List<Coordinate> waypoints = new ArrayList<>(Arrays.asList(new Coordinate(3, 7, 100), new Coordinate(7, 7, 100)));
		Hallway hallway = new Hallway(100, new Coordinate(3, 4, 0), new Coordinate(7, 10, 1), waypoints);

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		hallways.add(hallway);
		Coordinate exitCoord = new Coordinate(8, 11, 1);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}

	// two diagonal rooms connected by a horizontal hallway with a waypoint
	public static void test2RoomsHWaypoints() throws Exception {
		/*  X X X X X
		 *  X _ _ _ X
		 *  X _ _ _ ] - - - - - +
		 *  X _ _ _ X           |
		 *  X X X X X           |
		 *                      |
		 *                      |
		 *                    X ] X X
		 *                    X _ _ X
		 *                    X _ _ X
		 *                    X _ _ X
		 *                    X * X X
		 */

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0,},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 2},
				{0, 1, 1, 1, 0},
				{0, 0, 0, 0, 0} };

		int[][] tilesRoom2 = { {0, 2, 0, 0},
				{0, 1, 1, 0},
				{0, 1, 1, 0},
				{0, 1, 1, 0},
				{0, -1, 0, 0,} };

		Room room1 = new Room(new Coordinate(0, 0, 0), 5, 5, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(9, 7, 1), 4, 5, 1, tilesRoom2);
		List<Coordinate> waypoints = new ArrayList<>(Arrays.asList(new Coordinate(10, 2, 100)));
		Hallway hallway = new Hallway(100, new Coordinate(4, 2, 0), new Coordinate(10, 7, 1), waypoints);

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		hallways.add(hallway);
		Coordinate exitCoord = new Coordinate(10, 11, 1);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}

	// two diagonal rooms connected by a horizontal hallway with 2 waypoint
	public static void test2RoomsH2Waypoints() throws Exception {
		/*  X X X X X
		 *  X _ _ _ X
		 *  X _ _ _ ] - - - - - +
		 *  X _ _ _ X           |
		 *  X X X X X           |       X X X X
		 *                      + _ _ _ [ _ _ X
		 *                              X _ _ *
		 *                              X X X X
		 *
		 */

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0,},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 2},
				{0, 1, 1, 1, 0},
				{0, 0, 0, 0, 0} };

		int[][] tilesRoom2 = { {0, 0, 0, 0},
				{2, 1, 1, 0},
				{0, 1, 1, -1},
				{0, 0, 0, 0,} };

		Room room1 = new Room(new Coordinate(0, 0, 0), 5, 5, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(14, 4, 1), 4, 4, 1, tilesRoom2);
		List<Coordinate> waypoints = new ArrayList<>(Arrays.asList(new Coordinate(10, 2, 100), new Coordinate(10, 5, 100)));
		Hallway hallway = new Hallway(100, new Coordinate(4, 2, 0), new Coordinate(14, 5, 1), waypoints);

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		hallways.add(hallway);
		Coordinate exitCoord = new Coordinate(17, 6, 1);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}

	// 3 rooms and a horizontal hallway with a waypoint
	public static void test3RoomsHWaypoints() throws Exception {
		/*  X X X X X
		 *  X _ _ _ X
		 *  X _ _ _ ] - - - - - +
		 *  X _ _ _ X           |
		 *  X X X X X           |
		 *                      |
		 *                      |
		 *                    X ] X X
		 *  X X X X X X       X _ _ X
		 *  X _ _ _ _ X       X _ _ X
		 *  X _ _ _ _ ] _ _ _ ] _ _ X
		 *  X _ _ _ _ X       X X X X
		 *  X _ _ _ _ X
		 *  * _ _ _ _ X
		 *  X _ _ _ _ X
		 *  X X X X X X
		 */

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0,},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 2},
				{0, 1, 1, 1, 0},
				{0, 0, 0, 0, 0} };

		int[][] tilesRoom2 = { {0, 2, 0, 0},
				{0, 1, 1, 0},
				{0, 1, 1, 0},
				{2, 1, 1, 0},
				{0, 0, 0, 0,} };
		int[][] tilesRoom3 = { {0, 0, 0, 0, 0, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 2},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{-1, 1, 1, 1, 1, 0},
				{0, 0, 0, 0, 0, 0}};

		Room room1 = new Room(new Coordinate(0, 0, 0), 5, 5, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(9, 7, 1), 4, 5, 1, tilesRoom2);
		Room room3 = new Room(new Coordinate(0, 8, 2), 6, 8, 2, tilesRoom3);
		List<Coordinate> waypoints = new ArrayList<>(Arrays.asList(new Coordinate(10, 2, 1)));
		Hallway hallway1 = new Hallway(100, new Coordinate(4, 2, 0), new Coordinate(10, 7, 1), waypoints);
		Hallway hallway2 = new Hallway(101, new Coordinate(5, 10, 2), new Coordinate(9, 10, 1));

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		rooms.add(room3);
		hallways.add(hallway1);
		hallways.add(hallway2);
		Coordinate exitCoord = new Coordinate(0, 13, 2);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}

	// 3 rooms and a horizontal hallway with a waypoint
	public static void testRoom2Hallways() throws Exception {
		/*  X X X X X
		 *  X _ _ _ X
		 *  X _ _ _ ] - - - - - +
		 *  X _ _ _ X           |
		 *  X ] X X X           |
		 *    _                 |
		 *    _                 |
		 *    _               X ] X X
		 *  X ] X X X X       X _ _ X
		 *  X _ _ _ _ X       X _ _ X
		 *  X _ _ _ _ X       X _ _ X
		 *  X _ _ _ _ X       X X X X
		 *  X _ _ _ _ X
		 *  * _ _ _ _ X
		 *  X _ _ _ _ X
		 *  X X X X X X
		 */

		int[][] tilesRoom1 = { {0, 0, 0, 0, 0,},
				{0, 1, 1, 1, 0},
				{0, 1, 1, 1, 2},
				{0, 1, 1, 1, 0},
				{0, 2, 0, 0, 0} };

		int[][] tilesRoom2 = { {0, 2, 0, 0},
				{0, 1, 1, 0},
				{0, 1, 1, 0},
				{0, 1, 1, 0},
				{0, 0, 0, 0,} };

		int[][] tilesRoom3 = { {0, 2, 0, 0, 0, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{0, 1, 1, 1, 1, 0},
				{-1, 1, 1, 1, 1, 0},
				{0, 0, 0, 0, 0, 0}};

		Room room1 = new Room(new Coordinate(0, 0, 0), 5, 5, 0, tilesRoom1);
		Room room2 = new Room(new Coordinate(9, 7, 1), 4, 5, 1, tilesRoom2);
		Room room3 = new Room(new Coordinate(0, 8, 2), 6, 8, 2, tilesRoom3);
		List<Coordinate> waypoints = new ArrayList<>(Arrays.asList(new Coordinate(10, 2, 1)));
		Hallway hallway1 = new Hallway(100, new Coordinate(4, 2, 0), new Coordinate(10, 7, 1), waypoints);
		Hallway hallway2 = new Hallway(101, new Coordinate(1, 4, 0), new Coordinate(1, 8, 2));

		List<Room> rooms = new ArrayList<>();
		List<Hallway> hallways = new ArrayList<>();
		List<Item> items = new ArrayList<>();
		// TODO: populate items
		rooms.add(room1);
		rooms.add(room2);
		rooms.add(room3);
		hallways.add(hallway1);
		hallways.add(hallway2);
		Coordinate exitCoord = new Coordinate(0, 13, 2);
		Level level = new Level(0, rooms, hallways, items);
		GameView renderer = new GameView(level);
		renderer.renderLevel(Collections.emptyList(), Collections.emptyList());
	}
}
