package Game.Controller;

import Common.InputParser;
import Game.Model.*;
import JsonMappers.Object;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class FileInputParser implements InputParser {
    Scanner scanIn;

    public FileInputParser() throws FileNotFoundException {
        scanIn = new Scanner(new FileReader(new File("").getAbsolutePath()+"/app/src/snarl.levels"));
    }

    public FileInputParser(String fileName) throws FileNotFoundException {
        if (fileName == null) {
            fileName = new File("").getAbsolutePath()+"/app/src/snarl.levels";
        }
        scanIn = new Scanner(new FileReader(fileName));
    }

    @Override
    public String getInput() {
        StringBuilder sb = new StringBuilder();
        String test = "";
        while (scanIn.hasNextLine()) {
            test = scanIn.nextLine();
            if (test.equals("")) {
                sb.append("\n");
            }
            sb.append(test.trim());
        }
        scanIn.close();
        return sb.toString();
    }

    public JSONArray getLevelArray() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String stringToParse = getInput();
        String[] splitLevelsString = stringToParse.split("\n");
        int numLevels = Integer.parseInt(splitLevelsString[0]);
        if (splitLevelsString.length - 1 != numLevels) {
            throw new Exception("File format is poor");
        }
        JSONArray levels = new JSONArray();
        for(int i = 1; i < numLevels + 1; i++) {
            levels.put(new JSONObject(splitLevelsString[i]));
        }
        return levels;
    }

    @Override
    public List<Level> parseInputToGameObject() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String stringToParse = getInput();
        String[] splitLevelsString = stringToParse.split("\n");
        int numLevels = Integer.parseInt(splitLevelsString[0]);
        if (splitLevelsString.length - 1 != numLevels) {
            throw new Exception("File format is poor");
        }
        List<Level> levels = new LinkedList<>();
        for (int i = 1; i < numLevels; i++) {
            Level level = mapper.readValue(splitLevelsString[i], Level.class);
            levels.add(level);
        }
        return levels;
    }

    private List<Game.Model.Level> mapMapperObjectsToGameObjects(List<JsonMappers.Level> mapperLevels) throws Exception {
        List<Game.Model.Level> levels = new LinkedList<>();
        int levelCount = 1;
        // List of levels
        for (JsonMappers.Level level: mapperLevels) {
            List<Room> rooms = new LinkedList<>();
            int roomCount = 1;

            // Map rooms
            for(JsonMappers.Room room: level.getRooms()) {
                int width = room.getBounds().getColumns();
                int height = room.getBounds().getRows();
                Coordinate origin = new Coordinate(room.getOrigin()[0], room.getOrigin()[1], roomCount);
                rooms.add(new Room(origin, width, height, roomCount++, room.getLayout()));
            }

//            Map Hallways
            List<Hallway> hallways = new LinkedList<>();
            for(JsonMappers.Hallway hallway: level.getHallways()) {
                Coordinate from = new Coordinate(hallway.getFrom()[0], hallway.getFrom()[1]);
                Coordinate to = new Coordinate(hallway.getTo()[0], hallway.getTo()[1]);
                List<Coordinate> wayPoints = new LinkedList<>();
                for(Integer[] wayPoint : hallway.getWaypoints()) {
                    wayPoints.add(new Coordinate(wayPoint[0], wayPoint[1]));
                }
                hallways.add(new Hallway(roomCount++, from, to, wayPoints));
            }

            // Map Items from object
            List<Item> items = new LinkedList<>();
            for (Object object: level.getObjects()) {
                // TODO need to fix this if many objects get added later on
                ItemType itemType = object.getType().equals("key") ? ItemType.KEY : ItemType.EXIT;
                items.add(new Item(new Coordinate(object.getPosition()[0], object.getPosition()[1]), itemType));
            }

            levels.add(new Game.Model.Level(levelCount++, rooms, hallways, items));
        }
        return levels;
    }

    public static void main(String[] args) throws Exception {
        InputParser inputParser = new FileInputParser();
        inputParser.parseInputToGameObject();
    }
}
