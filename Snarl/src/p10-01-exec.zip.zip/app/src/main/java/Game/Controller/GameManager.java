package Game.Controller;

import Common.GameNotifier;
import Common.Observer;
import Game.Controller.Entity.MessageType;
import Game.Model.*;
import Game.Model.UI.GameViewType;
import Game.View.AsciiView;
import Game.View.GameView;
import Observer.LocalObserver;
import org.json.JSONObject;

import java.awt.event.KeyEvent;
import java.util.*;

public class GameManager implements GameNotifier {
    private GameView view;
    private GameState gameState;
    private RuleChecker ruleChecker;
    private static final int MAX_PLAYERS = 4;
    private static final int MIN_PLAYERS = 1;
    private static final int ENEMY_ID_LENGTH = 4;
    private final List<Observer> observers = new LinkedList<>();
    private boolean isObserverView = false;
    private static GameManager instance = null;

    private AsciiView asciiView;
    private GameViewType currentViewType;
    StringBuilder userNameBuilder = new StringBuilder();

    @Override
    public void notifySubscribers(GameState gameState) {
        if (!isObserverView) {
            return;
        }
        for (Observer o : observers) {
            o.renderView(gameState);
        }
    }

    @Override
    public void registerSubscriber(Observer o) {
        this.observers.add(o);
    }

    @Override
    public void removeSubscriber(Observer o) {
        this.observers.remove(o);
    }

    public GameManager() throws Exception {
        initGameManager(null);
    }

    /**
     * Initialize model, view, and ruleChecker
     *
     * @throws Exception
     */
    public GameManager(Level level, boolean isObserverView) throws Exception {
        this.isObserverView = isObserverView;
        initGameManager(level);
    }

    public void initGameManager(Level userBuiltLevel) throws Exception {
        Map<Integer, Level> levels = new LinkedHashMap<>();
        Level level = userBuiltLevel == null ? createLevel() : userBuiltLevel;
        levels.put(level.getLevelId(), level);
        Map<Integer, Room> rooms = new LinkedHashMap<>();
        Map<Integer, Hallway> hallways = new LinkedHashMap<>();
        List<Item> items = level.getItems();
        for (Room room : level.getRooms()) {
            rooms.put(room.getRoomId(), room);
        }

        for (Hallway hallway : level.getHallways()) {
            hallways.put(hallway.getHallwayId(), hallway);
        }

        this.gameState = new GameState(levels, rooms, hallways, items);
        this.view = new GameView(level);
        this.currentViewType = GameViewType.START_SCREEN;
        this.ruleChecker = new RuleChecker(this.gameState);
        registerSubscriber(new LocalObserver());
    }

    public static GameManager getInstance() throws Exception {
        if (instance == null) {
            instance = new GameManager();
        }
        return instance;
    }

    /**
     * Creates dummy level for us to test
     *
     * @return Level
     * @throws Exception
     */
    public Level createLevel() throws Exception {
        int[][] tilesRoom1 = {{0, 0, 0, 0, 0,},
                {0, 1, 1, 1, 0},
                {0, 1, 1, 1, 2},
                {0, 1, 1, 1, 0},
                {0, 0, 0, 0, 0}};

        int[][] tilesRoom2 = {{0, 0, 0, 0},
                {2, 1, 1, 0},
                {0, 1, 1, 0},
                {0, 0, 0, 0,}};

        Room room1 = new Room(new Coordinate(0, 0, 0), 5, 5, 0, tilesRoom1);
        Room room2 = new Room(new Coordinate(14, 4, 1), 4, 4, 1, tilesRoom2);
        List<Coordinate> waypoints = new ArrayList<>(Arrays.asList(new Coordinate(10, 2, 100), new Coordinate(10, 5, 100)));
        Hallway hallway = new Hallway(100, new Coordinate(4, 2, 0), new Coordinate(14, 5, 1), waypoints);

        List<Room> rooms = new ArrayList<>();
        List<Hallway> hallways = new ArrayList<>();
        List<Item> items = new ArrayList<>();
        rooms.add(room1);
        rooms.add(room2);
        hallways.add(hallway);
        Item key = new Item(new Coordinate(3, 1, 0), ItemType.KEY);
        Item exit = new Item(new Coordinate(17, 6, 1), ItemType.EXIT);

        items.add(key);
        items.add(exit);
        Level dummyLevel = new Level(0, rooms, hallways, items);

        return dummyLevel;
    }

    /**
     * Renders initial player view for each player.
     */
    public void start() throws Exception {
        if (this.gameState.getPlayers().size() < MIN_PLAYERS) {
            throw new Exception("Need to register at least 1 player to start the game.");
        }
        notifySubscribers(this.gameState);
        this.asciiView = new AsciiView(this.gameState.getCurrentLevel(), this, "General view");
        gameIntro();
        // TODO: CLEANUP
//        for(Player player : this.gameState.getPlayers()) {
//            System.out.println("-Player " + player.getActorId() + " view:");
//            renderPlayerView(player.getActorPosition(), ruleChecker.getTraversableTiles(player.getActorPosition()));
//        }
    }

    // probably not needed but we can make some cool animation for game start
    public void gameIntro() {
        asciiView.gameStartScreen();
    }

    public void transitionScreens(int keyCode, char keyChar, boolean isActionKey) {
        if (currentViewType.equals(GameViewType.START_SCREEN) && keyCode == KeyEvent.VK_ENTER) {
            currentViewType = GameViewType.GAME_PLAY_SCREEN;
            asciiView.beginGameScreen(this.gameState.getPlayers(), this.gameState.getCurrentPlayer().getPlayerName());
        } else if (currentViewType.equals(GameViewType.GAME_PLAY_SCREEN)) {
            try {
                switch (keyCode) {
                    case KeyEvent.VK_RIGHT:
                        movePlayersBy(0, 1);
                        asciiView.updateStoryPanel("You moved right!");
                        break;
                    case KeyEvent.VK_LEFT:
                        movePlayersBy(0, -1);
                        asciiView.updateStoryPanel("You moved left!");
                        break;
                    case KeyEvent.VK_UP:
                        movePlayersBy(-1, 0);
                        asciiView.updateStoryPanel("You moved up!");
                        break;
                    case KeyEvent.VK_DOWN:
                        movePlayersBy(1, 0);
                        asciiView.updateStoryPanel("You moved down!");
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                asciiView.updateStoryPanel("Oops you have hit a wall!");
            }
        } else if (currentViewType.equals(GameViewType.MENU_SCREEN)) {
            // TODO: CLEANUP
            // i love this view which lets the user type thier name on the gui. but lets keep this in the cmd line for now till the network stuff is sorted out
            if (keyCode == KeyEvent.VK_ENTER) {
//                asciiView.beginGameScreen();
            } else if (!isActionKey) {
                if (userNameBuilder.length() > 0 && keyCode == KeyEvent.VK_BACK_SPACE || keyCode == KeyEvent.VK_DELETE) {
                    userNameBuilder.setLength(userNameBuilder.length() - 1);
                    System.out.println(userNameBuilder.length());
                } else {
                    userNameBuilder.append(keyChar);
                }
                asciiView.gameMenuScreen(userNameBuilder.toString());

            }

        }
    }

    private void movePlayersBy(int dx, int dy) throws Exception {
        int currPosX = this.gameState.getCurrentPlayer().getActorPosition().getX();
        int currPosY = this.gameState.getCurrentPlayer().getActorPosition().getY();
        System.out.println("CURRENT POS"+ currPosX + "__"+currPosY);
        this.handlePlayerMove(currPosX + dx, currPosY + dy, this.gameState.getCurrentPlayer().getActorId());
        asciiView.updateGameScreen(this.gameState.getPlayers(), this.gameState.getCurrentLevel());
    }


    /**
     * Create player, determine id and initial location
     *
     * @return int representing player id
     * @throws Exception if there are too many players
     */
    public int createPlayer(String name) throws Exception {
        if (!checkNumPlayers()) {
            // exception, cannot have more than X players
            throw new Exception("Cannot have more than " + MAX_PLAYERS + " players");
        }

        int playerId = this.gameState.getPlayers().size() + 1;
        this.gameState.addPlayer(playerId, name, generateRandomLocation());
        return playerId;
    }

    /**
     * get list of actors in game state
     *
     * @return
     */
    public List<Player> getPlayers() {
        return this.gameState.getPlayers();
    }

    /**
     * Checks that the # of players does not exceed MAX_PLAYERS
     *
     * @return boolean
     */
    private boolean checkNumPlayers() {
        List<Player> players = this.gameState.getPlayers();

        return players.size() <= MAX_PLAYERS;
    }

    /**
     * Generate a random Coordinate, representing an unoccupied tile
     *
     * @return Corodinate
     */
    public Coordinate generateRandomLocation() {
        // TODO: allow location to be in hallway
        Random rand = new Random();
        Coordinate randLocation;

        Map<Integer, Room> rooms = this.gameState.getRooms();
        // need to change rand number generation since 0 was giving NPE
        int rand_room = rand.ints(1,rooms.size()).findFirst().getAsInt();
        Room room = rooms.get(rand_room);

        Coordinate roomPosn = room.getPosition();

        boolean foundTile = false;
        int rand_x = 0;
        int rand_y = 0;
        while (!foundTile) {

            int x = rand.nextInt(room.getWidth() - 1);
            int y = rand.nextInt(room.getHeight() - 1);
            //System.out.println(x + roomPosn.getX());
            //System.out.println(y + roomPosn.getY());

            try {
                if (room.getTiles()[y][x] == 1 && this.ruleChecker.validInitialLocation(new Coordinate(x + roomPosn.getX(), y + roomPosn.getY(), room.getRoomId()))) {
                    foundTile = true;
                }
            } catch (Exception e) {
                // we dont care
            }

            rand_x = x + roomPosn.getX();
            rand_y = y + roomPosn.getY();
        }

        randLocation = new Coordinate(rand_x, rand_y, room.getRoomId());

        return randLocation;
    }

    /**
     * Create enemy, determine id and initial location
     *
     * @return int representing enemy id
     * @throws Exception TODO
     */
    public int createEnemy() throws Exception {

        int adversaryId = generateUniqueId();
        this.gameState.addEnemy(adversaryId, generateRandomLocation());

        return adversaryId;
    }

    // generates unique int of specific length

    /**
     * Generate random id of length ENEMY_ID_LENGTH
     *
     * @return int
     */
    private int generateUniqueId() {
        String id = "";
        Random rand = new Random();
        for (int i = 0; i < ENEMY_ID_LENGTH; i++) {
            int rand_int = rand.nextInt(10);
            id += String.valueOf(rand_int);
        }

        return Integer.valueOf(id);
    }

    /**
     * Handles moves for a player and updates their view
     *
     * @param x:        int representing x coordinate that player wants to move to
     * @param y:        int representing y coordinate that player wants to move to
     * @param username: int representing the player's username
     * @throws Exception if move is invalid
     */
    public void handlePlayerMove(int x, int y, int username) throws Exception {

        for (Player player : this.gameState.getPlayers()) {
            System.out.println("-Player " + player.getActorId() + " view-");
            renderPlayerView(player.getActorPosition(), ruleChecker.getTraversableTiles(player.getActorPosition()));

            if (username == player.getActorId() && !player.isExpelled()) {
                Coordinate from = player.getActorPosition();
                Coordinate to = this.gameState.getCurrentLevel().determineRoom(x, y, from.getRoomId());
                if (this.ruleChecker.checkValidPlayerMove(from, to)) {
                    player.setActorPosition(to);
                    this.ruleChecker.handlePlayerInteractions(player.getActorId(), player.getActorPosition(), to);

                    if (player.isExpelled()) {
                        System.out.println("Sorry, you're dead!");
                    }

                    System.out.println("-Player " + username + " updated-");
                    renderPlayerView(player.getActorPosition(), ruleChecker.getTraversableTiles(player.getActorPosition()));
                } else {
                    throw new Exception("Invalid move: " + x + ", " + y);
                }

            }
            // Notify subscribers after gamestate change
            notifySubscribers(this.gameState);

            if (!stillPlaying()) {
                break;
            }
        }
    }

    /**
     * Checks if player with given id is still alive
     *
     * @param id: int player id
     * @return boolean
     */
    public boolean isAlive(int id) {
        boolean alive = false;
        for (Player player : this.gameState.getAlivePlayers()) {
            if (player.getActorId() == id) {
                alive = true;
            }
        }

        return alive;
    }

    /**
     * Remove player with given id from the game
     *
     * @param id: int
     */
    public void expelPlayer(int id) {
        ruleChecker.expelPlayer(id);
    }

    /**
     * Checks if game is still ongoing
     *
     * @return boolean
     */
    public boolean stillPlaying() {

        return this.gameState.getAlivePlayers().size() != 0 && !this.gameState.getGameOver();
    }

    /**
     * Refreshes the level
     */
    private void updateBoard() {
        this.view.updateLevel(this.gameState.getCurrentLevel());
    }


    /**
     * Renders the player view based on their location
     *
     * @param location: Coordinate of player's location
     * @param tiles:    List of tiles that are traversable from player's location
     */
    private void renderPlayerView(Coordinate location, List<Coordinate> tiles) {

        updateBoard();
        this.view.renderLevel(this.gameState.getPlayers(), this.gameState.getEnemies());
        this.view.renderPlayerView(location, tiles);
    }

    /**
     * Prints out the whole level, for debugging purposes
     */
    private void renderLevelView() {
        this.view.printLevel(this.gameState.getPlayers(), this.gameState.getEnemies());
    }

    /**
     * Check if the game is won or lost
     *
     * @return boolean
     */
    public boolean getWinStatus() {
        return this.gameState.getGameOver();
    }

    private void parseJSON(String message) {

        //stub
    }

    private JSONObject createJSON(MessageType type, String message) {
        //stub
        JSONObject jsonObj = new JSONObject();

        return jsonObj;
    }

    // Disconnects players once game is over
    public void stop(String message) {
        //stub
        for (Observer o : observers) {
            removeSubscriber(o);
        }
        System.out.println(message);
    }

    public static void main() {
        /*
	    GameManager manager = new GameManager();

        try {
            manager.start(8000);
            manager.stop();
        }
        catch (Exception e){
            System.out.println(e);
        }*/
    }
}
