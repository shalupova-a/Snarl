package Game.Model;

// Represents different types of objects in the game
public enum ItemType {
	KEY, 
	EXIT
}
