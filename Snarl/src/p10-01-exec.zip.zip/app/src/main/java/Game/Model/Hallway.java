package Game.Model;
//import org.graalvm.util.CollectionsUtil;

import java.util.*;

// Represents a hallway in a Snarl game
public class Hallway {

	private int hallwayId;
	private int length;
	private List<Coordinate> waypoints;
	private static final int HALLWAY_WIDTH = 1;
	private Coordinate from;
	private Coordinate to;
	private boolean initHorizontal; // is the hallway initially horizontal? determined in GameState
	private int[][] tiles;

	private List<Room> sections;

	public Hallway(int hallwayId, Coordinate from, Coordinate to) throws Exception {
		this.hallwayId = hallwayId;
		this.from = from;
		this.to = to;
		calculateLength();
		this.waypoints = new ArrayList<Coordinate>();
		this.initHorizontal = true;
		this.tiles = new int[this.length + 1][this.length + 1];
	}

	public Hallway(int hallwayId, Coordinate from, Coordinate to, List<Coordinate> waypoints) throws Exception {
		this(hallwayId, from, to);
		checkWaypoints(waypoints);
		this.sections = populateSections();
	}

	public List<Room> getHallwaySections() {
		return this.sections;
	}

	private List<Room> populateSections() throws Exception {
		List<Room> sections = new LinkedList<>();
		if(this.waypoints.size() == 0) {
			sections.add(createSection(this.from, this.to));
		} else{
			sections.add(createSection(this.from, this.waypoints.get(0)));
			for(int i = 0; i < waypoints.size() - 1; i++) {
				sections.add(createSection(this.waypoints.get(i), this.waypoints.get(i + 1)));
			}
			sections.add(createSection(this.waypoints.get(waypoints.size() - 1), to));
		}
		return sections;
	}

	private Room createSection(Coordinate from, Coordinate to) throws Exception {
		// horizontal hallway
		if(from.getX() == to.getX()) {
			int[][] tiles = new int[1][Math.abs(from.getY() - to.getY())];
			Arrays.stream(tiles).forEach(a -> Arrays.fill(a, 1));
			Coordinate origin = from.getY() > to.getY() ? to : from;
			return new Room(origin /** to is the origin since lesser point**/,
					Math.abs(from.getY() - to.getY()), 1/** hallways are one width if horizontal**/,
					Integer.MAX_VALUE, tiles);
		} else if (from.getY() == to.getY()) {
			int[][] tiles = new int[Math.abs(from.getX() - to.getX())][1];
			Arrays.stream(tiles).forEach(a -> Arrays.fill(a, 1));
			Coordinate origin = from.getX() > to.getX() ? to : from;
			return new Room(origin /** to is the origin since lesser point**/
					, 1/** hallways are one width if horizontal**/,
					Math.abs(from.getX() - to.getX()),
					Integer.MAX_VALUE, tiles);
		}

		throw new Exception("uhh this should not be happening since from and to should be on the same line");
	}

	/**
	 * Get hallway id
	 * @return int
	 */
	public int getHallwayId() {
		return this.hallwayId;
	}

	/**
	 * Get hallway length
	 * @return int
	 */
	public int getLength() {
		return this.length;
	}

	/**
	 * Get hallway waypoints
	 * @return List<Coordinate>
	 */
	public List<Coordinate> getWaypoints() {
		return Collections.unmodifiableList(this.waypoints);
	}

	/**
	 * Get hallway starting point
	 * @return Coordinate
	 */
	public Coordinate getFrom() {
		return this.from;
	}

	/**
	 * Get hallway end point
	 * @return Coordinate
	 */
	public Coordinate getTo() {
		return this.to;
	}

	/**
	 * Gets initHorizontal
	 * @return boolean
	 */
	public boolean getInitHorizontal() {
		return this.initHorizontal;
	}

	/**
	 * Set initHorizontal
	 * @param roomPosn coordinate for the room position
	 * @param width room width
	 */
	public void setInitHorizontal(Coordinate roomPosn, int width) {

		// Determine if the hallway starts as horizontal or vertical
		if(roomPosn.getX() == this.from.getX() || roomPosn.getX() + width - 1 == this.from.getX()) {
			this.initHorizontal = true;
		}
	}

	/**
	 * Set tiles
	 */
	public void setTiles() {

		int x = 0;
		int y = 0;

		System.out.println(this.length + "\n");
		for(int l = 0; l < this.length; l++) {
			if(initHorizontal) {
				x+=1;
			} else {
				y+=1;
			}
//			System.out.println(x);
//			System.out.println(y+ "\n");

			tiles[y][x] = 1;

			// if there is a waypoint at this location, draw it and change the direction of the hallway
			for (Coordinate waypointPosn : this.waypoints) {
				if (x + from.getX() == waypointPosn.getX() && y + from.getY() == waypointPosn.getY()) {
					tiles[y][x] = -1;
					initHorizontal = !initHorizontal;
				}
			}
		}
	}

	/**
	 * Gets tiles
	 * @return int[][]
	 */
	public int[][] getTiles() {
		return this.tiles;
	}

	/**
	 * Check that a point is within the hallway
	 * @param point: Coordinate
	 * @return boolean
	 */
	public boolean withinBounds(Coordinate point) {
		//TODO implement
		if(point.getX() >= from.getX() && point.getX() <= from.getX() + length &&
				point.getY() >= from.getY() && point.getY() <= from.getY() + length) {
			//System.out.println("withinBounds");
			//System.out.println(point.getX());
			//System.out.println(point.getY());
			return tiles[point.getY() - this.from.getY()][point.getX() - this.from.getX()] == 1
					|| tiles[point.getY() - this.from.getY()][point.getX() - this.from.getX()] == -1
					|| (point.getX() == to.getX() && point.getY() == to.getY());
		}

		return false;
	}

	/**
	 * Calculates the length of the hallway
	 */
	private void calculateLength() {
		this.length = Math.abs(this.from.getX() - this.to.getX()) + Math.abs(this.from.getY() - this.to.getY()) - 1;
	}

	/**
	 * Checks that the number of waypoints doesn't exceed the length of the hallway
	 * @param waypoints: List<Coordinate>
	 * @throws Exception
	 */
	private void checkWaypoints(List<Coordinate> waypoints) throws Exception {
//		if(waypoints.size() > this.length - 1) {
//			throw new Exception("Too many waypoints");
//		}
		this.waypoints = waypoints;
	}
}
