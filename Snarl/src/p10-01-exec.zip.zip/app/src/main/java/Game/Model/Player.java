package Game.Model;

import java.util.List;
import java.util.ArrayList;

public class Player extends Actor{
    private boolean isExpelled;
    private List<Item> inventory;
    private String playerName;
    public Player(int actorId, ActorType type, Coordinate position) {
        super(actorId, type, position);
        this.isExpelled = false;
        this.inventory = new ArrayList<>();
    }

    /**
     * Get player inventory
     * @return List<Item>
     */
    public List<Item> getInventory() {
        return this.inventory;
    }

    /**
     * Add item to player inventory
     * @param heldItem: Item
     */
    public void addToInventory(Item heldItem) {
        //System.out.println("DEBUG: adding to inventory in Actor");
        this.inventory.add(heldItem);
    }

    /**
     * Detemine if player is expelled from game
     * @return boolean
     */
    public boolean isExpelled() {
        return isExpelled;
    }

    /**
     * Set isExpelled
     * @param expelled: boolean
     */
    public void setExpelled(boolean expelled) {
        isExpelled = expelled;
    }

    /**
     * Check if player's inventory contains a key item
     * @return boolean
     */
    public boolean hasKey() {
        return inventory.stream().anyMatch(i -> i.getType() == ItemType.KEY);
    }

    public void setPlayerName(String name) {
        this.playerName = name;
    }

    public String getPlayerName() {
        return playerName;
    }
}
