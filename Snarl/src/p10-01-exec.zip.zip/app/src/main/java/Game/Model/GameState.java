package Game.Model;

import java.util.*;
import java.util.stream.Collectors;

public class GameState {
    private Map<Integer, Level> levels;
    private Map<Integer, Room> rooms;
    private Map<Integer, Hallway> hallways;
    private List<Item> items;
    private Level currentLevel;
    private List<Player> players;
    private List<Adversary> enemies;
    private boolean gameOver;
    private Player currentPlayer;
    public GameState(Map<Integer, Level> levels, Map<Integer, Room> rooms, Map<Integer, Hallway> hallways, List<Item> items) throws Exception {
        this.levels = levels;
        this.rooms = rooms;
        setFromRoomHallways(hallways);
        setHallwayTiles();
        this.items = items;
        this.players = new ArrayList<>();
        this.enemies = new ArrayList<>();
        Map.Entry<Integer, Level> firstLevel = this.levels.entrySet().iterator().next();
        this.currentLevel = firstLevel.getValue();
        this.gameOver = false;
    }

    /**
     * Determines list of players that are currently alive
     * @return List<Player>
     */
    public List<Player> getAlivePlayers() {
        List<Player> alivePlayers = new ArrayList<>();
        for (Player player : players) {
            if (!player.isExpelled()) {
                //System.out.println(player.getActorId());
                alivePlayers.add(player);
            }
        }
        return Collections.unmodifiableList(alivePlayers);
    }

    /**
     * Determines all players registered in the game
     * @return List<Player>
     */
    public List<Player> getPlayers() {
        return Collections.unmodifiableList(this.players);
    }

    /**
     * Determines all enemies registered in the game
     * @return List<Adversary>
     */
    public List<Adversary> getEnemies() {
        return Collections.unmodifiableList(this.enemies);
    }

    /**
     * Adds a player to the game
     * @param playerId - player Id
     * @param location - player position coordinate to be placed at
     */
    public void addPlayer(int playerId, String name, Coordinate location) {
        Player player = new Player(playerId, ActorType.PLAYER, location);
        if(currentPlayer == null) {
            currentPlayer = player;
        }
        player.setPlayerName(name);
        this.players.add(player);
    }

    /**
     * Adds an enemy to the game
     * @param enemyId - Id of the enemy
     * @param location - location coordinate of the enemy
     */
    // TODO generate random adversary type
    public void addEnemy(int enemyId, Coordinate location) { this.enemies.add(new Adversary(enemyId, ActorType.GHOST, location)); }

    /**
     * Determines all the rooms in the current level
     * @return Map<Integer, Room>
     */
    public Map<Integer, Room> getRooms() {
        return this.rooms;
    }

    /**
     * Determines all the hallways in the current level
     * @return Map<Integer, Hallway>
     */
    public Map<Integer, Hallway> getHallways() { return this.hallways;}

    /**
     * Determines all the items in the the current level
     * @return List<Item>
     */
    public List<Item> getItems() { return this.items; }

    /**
     * Determines all the levels in the game
     * @return Map<Integer, Level>
     */
    public Map<Integer, Level> getLevels() {
        return this.levels;
    }

    /**
     * Determines the current level of the game
     * @return Level
     */
    public Level getCurrentLevel() {
        return this.currentLevel;
    }

    public Player getCurrentPlayer() {
        return this.currentPlayer;
    }

    /**
     * Kills a player
     * @param deadPlayerId: id representing dead player
     */
    public void killPlayer(int deadPlayerId) {
        for(Player player : this.players) {
            if(player.getActorId() == deadPlayerId) {
                player.setExpelled(true);
            }
        }
    }

    //TODO: move logic to RuleChecker?
    /**
     * Add item to player's inventory
     * @param playerId: int
     * @param location: Coordinate
     */
    public void addItemToPlayer(int playerId, Coordinate location) {
        for(Player player : this.players) {
            if(player.getActorId() == playerId) {
                Coordinate playerPosn = player.getActorPosition();

                for (Item item : this.items) {
                    Coordinate itemPosn = item.getPosition();
                    // TODO: add RoomID check
                    if(itemPosn.getX() == playerPosn.getX() && itemPosn.getY() == playerPosn.getY()) {
                        if(item.getType() == ItemType.EXIT) {
                            System.out.println("DEBUG: Found exit object");
                            setGameOver(keyFound());
                        } else {
                            System.out.println("DEBUG: Add key to player inventory");
                            player.addToInventory(item);
                            currentLevel.removeItem(item);
                        }
                    }
                }
            }
        }
    }

    /**
     * Checks if any players have found the key item
     *
     * @return boolean
     */
    private boolean keyFound() {

        System.out.println("DEBUG: Check if any players have found key");
        boolean found = false;

        for(Player player : players) {
            if(player.hasKey()) {
                return true;
            }
        }
        return found;
    }

    /**
     * Sets gameOver variable to over
     * @param over: boolean
     */
    private void setGameOver(boolean over) {
        System.out.println("DEBUG: Set game over to " + over);
        this.gameOver = over;
    }

    /**
     * Determines if the game is over
     * @return boolean
     */
    public boolean getGameOver() {
        return this.gameOver;
    }

    /**
     * Sets initHorizontal field in for each Hallway based on which room it starts at
     * @param hallways: Map<Integer, Hallway>
     * @throws Exception
     */
    private void setFromRoomHallways(Map<Integer, Hallway> hallways) throws Exception {

        this.hallways = hallways;

        for (Map.Entry<Integer, Hallway> entry : this.hallways.entrySet()) {
            Hallway hallway = entry.getValue();
            Coordinate from = hallway.getFrom();

            try {
                int roomId = this.currentLevel.findRoom(from);

                Room fromRoom = this.rooms.get(roomId);
                hallway.setInitHorizontal(fromRoom.getPosition(), fromRoom.getWidth());
            } catch(Exception e) {
                System.out.println("Something went wrong @ setFromRoomHallways");
            }
            //System.out.println("RoomID");
            //System.out.println(roomId);

        }
    }

    /**
     * Sets hallway tiles
     */
    private void setHallwayTiles() {

        for(Map.Entry<Integer, Hallway> entry : this.hallways.entrySet()) {
            Hallway hallway = entry.getValue();
            //System.out.println("Hallway id");
            //System.out.println(hallway.getHallwayId());
            //System.out.println("\n");

            hallway.setTiles();
        }
    }
}
