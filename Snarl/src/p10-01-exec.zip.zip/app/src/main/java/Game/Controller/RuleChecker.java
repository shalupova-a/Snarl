package Game.Controller;

import Game.Model.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class RuleChecker {

    private GameState model;

    private static final int NUM_MOVES = 2;

    public RuleChecker(GameState model) {
        this.model = model;
    }


    /**
     * Determines all Coordinates NUM_MOVES cardinal moves away from given Coordinate
     * @param position: Coordinate
     * @return List<Coordinate>
     */
    public List<Coordinate> getTraversableTiles(Coordinate position) {
        List<Coordinate> validTiles = new ArrayList<>();

        for(int i = 0; i < NUM_MOVES + 1; i++) {
            for(int j = 0; j < NUM_MOVES + 1; j++) {
                validTiles.add(new Coordinate(position.getX() + i, position.getY() + j));
                validTiles.add(new Coordinate(position.getX() - i, position.getY() - j));
                validTiles.add(new Coordinate(position.getX() + i, position.getY() - j));
                validTiles.add(new Coordinate(position.getX() - i, position.getY() + j));
            }
        }

        return validTiles;
    }

    /**
     * Check that the given Coordinate is reachable, valid, and not occupied by a player
     * @param to: Coordinate representing a tile
     * @param reachableTiles: List<Coordinate> representing reachable tiles for a player
     * @return boolean: if a player can move to this tile
     */
    public boolean checkValidPlayerMove(Coordinate from, Coordinate to) {
        System.out.println(reachableTile(to, getTraversableTiles(from)));
        System.out.println(validSpace(to));
        System.out.println(!occupiedByPlayer(to));

        return reachableTile(to, getTraversableTiles(from)) && validSpace(to) && !occupiedByPlayer(to);
    }

    /**
     * Checks that the given Coordinate is valid and unoccupied by items or other enemies
     * @param to: Coordinate representing tile
     * @return boolean: if an enemy can move to this tile
     */
    public boolean checkValidEnemyMove(Coordinate to) {

        return validSpace(to) && !occupiedByItem(to) && !occupiedByEnemy(to);
    }

    /**
     * Handles player interactions with adversaries and objects
     * @param playerId: int
     * @param playerPosn: Coordinate
     * @param to: Coordinate representing tile player wants to move to
     */
    public void handlePlayerInteractions(int playerId, Coordinate playerPosn, Coordinate to) {
        if(occupiedByEnemy(to)) {
            //System.out.println("DEBUG: occupied by enemy, about to die.");
            expelPlayer(playerId);
        } else if(occupiedByItem(to)) {
            //System.out.println("DEBUG: occupied by item, adding to inventory");
            handleItemInteractions(playerId, playerPosn);
        } else {
            //System.out.println("DEBUG: no interactions found for this player.");
        }
    }

    /**
     * STUB: Handles enemy interactions with players
     * @param to: Coordinate enemy wants to move to
     */
    public void handleEnemyInteractions(Coordinate to) {
        if(checkValidEnemyMove(to)) {
            if(occupiedByPlayer(to)) {
                //expelPlayer();
            }
        }
    }

    /**
     * Checks that given tile is a valid inital location for an entity
     * @param to: Coordinate representing tile
     * @return boolean
     */
    public boolean validInitialLocation(Coordinate to) {
        // Initially, we are assuming the tile has to be unoccupied and valid to place player/adversary
        return !occupiedByEnemy(to) && validSpace(to) && !occupiedByPlayer(to) && !occupiedByItem(to);
    }

    /**
     * Checks if tile is occupied by an enemy
     * @param to: Coordinate representing tile
     * @return boolean
     */
    private boolean occupiedByEnemy(Coordinate to) {
        //System.out.println("DEBUG: check if tile occupied by enemy");
        List<Adversary> enemies = this.model.getEnemies();
        for(Adversary enemy : enemies) {
            Coordinate enemyPosn = enemy.getActorPosition();
            if(enemyPosn.checkEqualCoordinates(to)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Kills a player
     * @param playerId: id of player
     */
    public void expelPlayer(int playerId) {
        this.model.killPlayer(playerId);
    }

    /**
     * Adds item to player's inventory if it's a key
     * @param playerId: int
     * @param playerPosn: Coordinate of player
     */
    // TODO: move logic from model to here
    private void handleItemInteractions(int playerId, Coordinate playerPosn) {
        this.model.addItemToPlayer(playerId, playerPosn);
    }

    /**
     * Check that tile is a valid tile (no more than 2 cardinal moves away)
     * @param to: Coordinate representing tile
     * @param validTiles: List<Coordinate> of valid tiles
     * @return boolean
     */
    private boolean reachableTile(Coordinate to, List<Coordinate> validTiles) {

        for(Coordinate tile : validTiles) {
            if(to.getX() == tile.getX() && to.getY() == tile.getY()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check that tile is not a wall or exit
     * @param to: Coordinate representing tile
     * @return boolean
     */
    private boolean validSpace(Coordinate to) {
        Map<Integer, Room> rooms = this.model.getRooms();
        Map<Integer, Hallway> hallways = this.model.getHallways();

        int roomId = to.getRoomId();

        boolean withinRoomBounds = false;
        boolean withinHallwayBounds = false;

        for (Map.Entry mapElement : rooms.entrySet()) {
            Room room = (Room) mapElement.getValue();

            if(room.getRoomId() == roomId) {
                withinRoomBounds = room.withinBounds(to);
            }
        }


        for (Map.Entry mapElement : hallways.entrySet()) {
            Hallway hallway = (Hallway) mapElement.getValue();

            if(hallway.getHallwayId() == roomId) {
                withinHallwayBounds = hallway.withinBounds(to);
            }
        }

        return withinRoomBounds || withinHallwayBounds || occupiedByItem(to);
    }

    /**
     * Check that there isn't another player at this tile
     * @param to: Coordinate representing tile
     * @return boolean
     */
    private boolean occupiedByPlayer(Coordinate to) {
        List<Player> players = this.model.getAlivePlayers();

        for(Player player : players) {
            Coordinate playerPosn = player.getActorPosition();
            if(playerPosn.checkEqualCoordinates(to)) {
                //System.out.println("DEBUG: player found at this tile.");
                return true;
            }
        }

        return false;
    }

    /**
     * Check if there is an item at this tile
     * @param to: Coordinate representing tile
     * @return boolean
     */
    public boolean occupiedByItem(Coordinate to) {
        //System.out.println("DEBUG: Checking if tile occupied by item");
        Level level = this.model.getCurrentLevel();
        for(Item item : level.getItems()) {
            Coordinate itemPosn = item.getPosition();
            if(itemPosn.getX() == to.getX() && itemPosn.getY() == to.getY()) {
                return true;
            }
        }
        return false;
    }
}