package Game.Model;

public enum ActorType {
    PLAYER,
    ZOMBIE,
    GHOST
}