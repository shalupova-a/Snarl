package Game.View;

import Game.Controller.GameManager;
import Game.Model.*;
import Game.Model.UI.GameViewType;
import Game.Model.UI.TextureType;
import asciiPanel.AsciiPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;

public class AsciiView extends JFrame implements KeyListener {
    protected AsciiPanel gamePanel;
    protected AsciiPanel playerInfoPanel;
    protected AsciiPanel storyPanel;
    protected Level level;
    private GameManager manager;

    public AsciiView(Level level, String title) {
        this.level = level;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        ViewPanelFactory viewPanelFactory = new ViewPanelFactory();
        gamePanel = viewPanelFactory.getAsciiPanel("GAME");
        storyPanel = viewPanelFactory.getAsciiPanel("STORY");
        playerInfoPanel = viewPanelFactory.getAsciiPanel("INVENTORY");
        this.setTitle(title);
        this.manager = null;
    }

    // We are adding the manager because GUI programs are different than cmd line programs
    // command line programs wait on user input, but gui programs are event driven, which means
    // the user input is obtained as part of an event listener and should be updated in the manager
    // We can actually go for a pub sub or observer model and update the manager, but for now we just use the manager object here
    // TODO maybe we can clean it up when everything gels together
    // Basic idea : Manager -> starts screen -> screen listens key clicks and input from user -> sends back to manager for further work -> manager asks view for more rendering etcc
    public AsciiView(Level level, GameManager manager, String title) {
        this(level, title);
        this.manager = manager;
    }


    public void gameStartScreen() {
        gamePanel.writeCenter(TextureType.BLOCK.getCodePoint() + "Welcome to Snarl!" + TextureType.BLOCK.getCodePoint(), 12, Color.cyan);
        add(gamePanel);
        pack();
        // 13 is the 13 line in the panel
        gamePanel.writeCenter("Press [Enter] to continue ...", 13);
        gamePanel.repaint();
    }


    public void beginGameScreen(List<Player> players, String userName) {
        gamePanel.clear();
        repaint();
        add(playerInfoPanel, BorderLayout.EAST);
        add(storyPanel, BorderLayout.SOUTH);
        add(gamePanel, BorderLayout.WEST);
        initStoryPanel();

        storyPanel.writeCenter("Hello " + userName + ", you are in snarl game", 7);
        printHallways(level.getHallways());
        printRooms(level.getRooms());
        placeItems(level.getItems());
        placePlayers(players);
        pack();
        repaint();
    }

    public void updateGameScreen(List<Player> players, Level level) {
        gamePanel.clear();
        repaint();
        printHallways(level.getHallways());
        printRooms(level.getRooms());
        placeItems(level.getItems());
        placePlayers(players);
        pack();
        repaint();
    }

    public void gameMenuScreen(String username) {
        gamePanel.clear();
        gamePanel.writeCenter("Please enter your name", 12, Color.cyan);
        add(gamePanel);
        pack();
        // 13 is the 13 line in the panel
        gamePanel.writeCenter(username, 14);
        gamePanel.repaint();
    }

    private void printRooms(List<Room> roomList) {
        for (Room room : roomList) {
            print2dArray(room.getTiles(), room.getPosition());
        }
    }

    private void printHallways(List<Hallway> hallways) {
        for (Hallway hallway : hallways) {
            printRooms(hallway.getHallwaySections());
        }
    }

    private void placeItems(List<Item> items) {
        for (Item item : items) {
            if (item.getType().equals(ItemType.KEY)) {
                writeTextureToGamePanel(item.getPosition().getY(), item.getPosition().getX(), TextureType.KEY);
            } else if (item.getType().equals(ItemType.EXIT)) {
                writeTextureToGamePanel(item.getPosition().getY(), item.getPosition().getX(), TextureType.EXIT);
            }
        }
    }

    private void placePlayers(List<Player> players) {
        for (Player player : players) {
            writeTextureToGamePanel(player.getActorPosition().getY(), player.getActorPosition().getX(), TextureType.PLAYER);
        }
    }

    /**
     * Prints out a 2d array grid of valid chars
     * Instead of printing the whole game as a whole, this provides a small array which represents a room
     * Hallways can also be thought of as rooms with width or height set as 1 . so a hallway with 3 waypoints can be broken down as 3 rooms
     * <p>
     * Origin is the coordinate for the room's top left corner. for hallway section it can be the from point or waypoint
     *
     * @param grid: char[][]
     */
    private void print2dArray(int[][] grid, Coordinate origin) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                int tileInput = grid[i][j];
                int x = j + origin.getY();
                int y = i + origin.getX();
                int w = grid.length - 1;
                int h = grid[i].length - 1;

                // BLANK SPACE
                if (tileInput == TextureType.BLANK.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.BLANK);
                    // DOOR
                } else if (tileInput == TextureType.DOOR.getTileInput()) {
                    writeTextureToGamePanel(x, y, TextureType.DOOR);
                    // WALLS, we are checking corners so it has a nice smooth edge!
                } else if (tileInput == TextureType.BLOCK.getTileInput() && TileUtils.isBorder(i, j, grid.length - 1, grid[i].length - 1)) {
                    if (TileUtils.isLeftCorner(i, j)) {
                        writeTextureToGamePanel(x, y, TextureType.TOP_LEFT_CORNER);
                    } else if (TileUtils.isBottomLeftCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.BOTTOM_LEFT_CORNER);
                    } else if (TileUtils.isBottomRightCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.BOTTOM_RIGHT_CORNER);
                    } else if (TileUtils.isRightCorner(i, j, w, h)) {
                        writeTextureToGamePanel(x, y, TextureType.TOP_RIGHT_CORNER);
                    } else {
                        // vertical border has vertical line and vice versa
                        if (TileUtils.isVerticalBorder(i, j, w, h)) {
                            writeTextureToGamePanel(x, y, TextureType.VERTICAL_WALL);
                        } else {
                            writeTextureToGamePanel(x, y, TextureType.HORIZONTAL_WALL);
                        }
                    }
                }
            }
        }
    }


    private void writeTextureToGamePanel(int x, int y, TextureType tt) {
        gamePanel.write(tt.getCodePoint(), x, y, tt.getColor());
    }

    private void writeTextureToStoryPanel(int x, int y, TextureType tt, Color color) {
        storyPanel.write(tt.getCodePoint(), x, y, color != null ? color : tt.getColor());
    }

    private void writeTextureToStoryPanel(int x, int y, TextureType tt) {
        storyPanel.write(tt.getCodePoint(), x, y, tt.getColor());
        storyPanel.repaint();
    }
    /** public method to write stuff to story panel (panel at the bottom of screen) to give feedback to players and build the game story **/
    public void updateStoryPanel(String text) {
        storyPanel.clear();
        storyPanel.writeCenter(text, 10);
        storyPanel.repaint();
    }


    /**
     * Creates the story panel which is the panel at the bottom that shows what the player should do, ask for moves etc...
     */
    private void initStoryPanel() {
        int W = storyPanel.getWidthInCharacters();
        int H = storyPanel.getHeightInCharacters();
        for (int i = 0; i < W; i++) {
            for (int j = 0; j < H; j++) {
                if (TileUtils.isBorder(i, j, W - 1, H - 1)) {
                    if (i == 0 || i == W - 1) {
                        if (TileUtils.isCornerTile(i, j, W - 1, H - 1)) {
                            writeTextureToStoryPanel(i, j, TextureType.BLOCK, Color.gray);
                            continue;
                        }
                        writeTextureToStoryPanel(i, j, TextureType.VERTICAL_WALL);
                    } else {
                        writeTextureToStoryPanel(i, j, TextureType.HORIZONTAL_WALL);
                    }
                }
            }
        }
    }

    public void repaint() {
        gamePanel.repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        this.manager.transitionScreens(e.getKeyCode(), e.getKeyChar(), e.isActionKey());
    }
}
