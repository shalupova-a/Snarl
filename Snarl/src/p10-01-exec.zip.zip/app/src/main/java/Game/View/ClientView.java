package Game.View;
import Remote.Client;
import Game.Model.*;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class ClientView extends AsciiView {

    private Client client;
    private boolean playing = false;

    public ClientView(Level level, Client client, String title) {
        super(level, title);
        this.client = client;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //this.client.transitionScreens(e.getKeyCode(), e.getKeyChar(), e.isActionKey());
    }


}