package Game.Model;

import java.util.*;

// A Level in a Snarl Game
public class Level {

    private int levelId;
    private List<Room> rooms;
    private List<Hallway> hallways;
    private List<Item> items;

    public Level(int levelId, List<Room> rooms, List<Hallway> hallways, List<Item> items) throws Exception {
        this.levelId = levelId;
        checkUniqueRoomsHallways(rooms, hallways);
        checkValidItems(items);
    }

    /**
     * Get level id
     * @return int
     */
    public int getLevelId() {
        return this.levelId;
    }

    /**
     * Get all the rooms in the level
     * @return List<Room>
     */
    public List<Room> getRooms() {
	    return Collections.unmodifiableList(this.rooms);
    }

    /**
     * Get all the hallways in the level
     * @return List<Hallway>
     */
    public List<Hallway> getHallways() { return Collections.unmodifiableList(this.hallways); }

    /**
     * Get all the items in the level
     * @return List<Item>
     */
    public List<Item> getItems() { return Collections.unmodifiableList(this.items); }

    /**
     * Remove an item from the level
     * @param item: Item
     */
    public void removeItem(Item item) {
        //System.out.println("DEBUG: Removing item from level");
        items.remove(item);
    }

    /**
     * Determines the room id of given x and y
     * @param x: int
     * @param y: int
     * @param prevRoomId: int
     * @return Coordinate
     */
    public Coordinate determineRoom(int x, int y, int prevRoomId) throws Exception {
        Coordinate tile = new Coordinate(x, y, prevRoomId);
        Room prevRoom = this.rooms.get(prevRoomId);
        if(!prevRoom.withinBounds(tile)) {
            int newRoomId = findRoom(tile);
            tile = new Coordinate(x, y, newRoomId);
        }

        return tile;
    }

    /**
     * Find room that x and y coordinates belong to
     * @param tile: Coordinate
     * @return int roomId
     */
    public int findRoom(Coordinate tile) throws Exception {

        for (Room room : this.rooms) {

            if(room.withinBounds(tile)) {
                return room.getRoomId();
            }
        }

        for (Hallway hallway : this.hallways) {

            if(hallway.withinBounds(tile)) {
                return hallway.getHallwayId();
            }
        }

        throw new Exception("No room found that contains the given tile.");
    }

    /**
     * Check that rooms and hallways have unique ids and do not overlap
     * @param rooms: List<Room>
     * @throws Exception
     */
    private void checkUniqueRoomsHallways(List<Room> rooms, List<Hallway> hallways) throws Exception {
        Set<Integer> ids = new HashSet<>();
        for(Hallway hallway : hallways) {
            ids.add(hallway.getHallwayId());
        }

        for(Room room : rooms) {
            ids.add(room.getRoomId());
        }

        if(ids.size() != hallways.size() + rooms.size()) {
            throw new Exception("Hallways and rooms cannot have the same ID in a level.");
        }

        // TODO: check that hallways and rooms do not overlap

        this.rooms = rooms;
        this.hallways = hallways;
    }

    /**
     * Check that a level has both key and valid exit
     * @param items: List<Item>
     * @throws Exception
     */
    private void checkValidItems(List<Item> items) throws Exception {
        // TODO: validate item coordinate

        boolean foundKey = false;
        boolean foundExit = false;

        for(Item item : items) {
            if(item.getType() == ItemType.KEY) {
                foundKey = true;
            } else if(item.getType() == ItemType.EXIT) {
                foundExit = true;
                checkLevelExit(item.getPosition());
            } else {
                throw new Exception("Invalid Item type.");
            }
        }

        if(!foundKey) {
            throw new Exception("Items list did not contain a key.");
        }

        if(!foundExit) {
            throw new Exception("Items list did not contain an exit.");
        }

        this.items = items;
    }

    /**
     * Check that the level exit is at an edge
     * @param levelExit : Coordinate
     * @throws Exception
     */
    private void checkLevelExit(Coordinate levelExit) throws Exception {

        for(Room room : this.rooms) {
            if(levelExit.getRoomId() == room.getRoomId()) {
                Coordinate roomPosn = room.getPosition();
                if(!(levelExit.getX() - roomPosn.getX() == 0 || levelExit.getY() - roomPosn.getY() == 0 || levelExit.getX() == roomPosn.getX() + room.getWidth() - 1 ||
                        levelExit.getY() == roomPosn.getY() + room.getHeight() - 1)) {
                    throw new Exception("Coordinate of level exit is not at an edge.");
                }
            }
        }

    }
}
