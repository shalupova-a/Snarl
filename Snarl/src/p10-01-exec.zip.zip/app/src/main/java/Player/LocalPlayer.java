package Player;

import Common.Player;
import Game.Controller.GameManager;
import Game.Model.Coordinate;

import java.util.Scanner;

public class LocalPlayer implements Player {
    private final Scanner scanner = new Scanner(System.in);
    private final int id;
    private final String name;
    private Integer[] position;

    public LocalPlayer(String name) {
        this.name = name;
        this.id = 0;
        this.position = null;
    }

    public LocalPlayer(int id, String name) throws Exception {
        this.id = id;
        this.name = name;
        this.position = null;
    }

    public int getId() {
        return id;
    }

    public String getName() { return this.name; }

    @Override
    public void updatePlayerPosition(Integer[] playerPosn) throws Exception {
        this.position = playerPosn;
    }


    @Override
    public void updatePlayerPosition(Coordinate playerPosn) throws Exception {
        this.position = new Integer[]{playerPosn.getX(), playerPosn.getY()};
    }

    public Integer[] getPosition() {
        return this.position;
    }

    /**
     * Prompt user for move and handle user input
     */
    @Override
    public void promptPlayerMove() {

        boolean validInput = false;

        while(!validInput) {

            System.out.println("-Player " + name + " move-");
            System.out.println("Please enter number for action:\n\t1. Move to a different tile. \n\t2. Stay put\n\t3. Exit game");
            try {
                int input = scanner.nextInt();
                switch (input) {
                    case 1:
                        System.out.println("Note that you can only move 2 cardinal tiles at a time to an unoccupied tile.");
                        System.out.println("\tEnter x coordinate of destination:");
                        int xCoord = scanner.nextInt();
                        System.out.println("\tEnter y coordinate of destination:");
                        int yCoord = scanner.nextInt();
                        this.updatePlayerPosition(new Coordinate(xCoord, yCoord));
                        validInput = true;
                        break;
                    case 2:
                        System.out.println("Staying put!");
                        validInput = true;
                        break;
                    case 3:
                        System.out.println("Exiting game.");
                        //manager.expelPlayer(id);
                        validInput = true;
                        break;
                    default:
                        System.out.println("Invalid option. Try again.");
                        break;
                }

            } catch (Exception e) {
                System.out.println("Invalid input. Try again\n" + e);
            }
        }
    }

}
