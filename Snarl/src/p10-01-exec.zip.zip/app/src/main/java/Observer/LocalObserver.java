package Observer;

import Common.Observer;
import Game.Model.GameState;
import Game.View.GameView;

public class LocalObserver implements Observer {
    private GameView gameView;

    public LocalObserver() {
    }

    @Override
    public void renderView(GameState gameState) {
        // render the view to ascii
        gameView = new GameView(gameState.getCurrentLevel());
        System.out.println("Observer View:");
        this.gameView.printLevel(gameState.getPlayers(), gameState.getEnemies());
    }
}
