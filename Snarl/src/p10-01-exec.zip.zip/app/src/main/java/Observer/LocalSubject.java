package Observer;

import Common.Observer;
import Common.GameNotifier;
import Game.Model.GameState;

import java.util.List;

public class LocalSubject implements GameNotifier {
    List<Observer> observers;

    @Override
    public void notifySubscribers(GameState gameState) {
        for (Observer o : observers) {
            o.renderView(gameState);
        }
    }

    @Override
    public void registerSubscriber(Observer o) {
        this.observers.add(o);
    }

    @Override
    public void removeSubscriber(Observer o) {
        this.observers.remove(o);
    }
}
