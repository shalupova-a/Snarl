package Remote;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import org.json.*;

import ManagerSrc.UI.*;
import ManagerSrc.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.awt.event.KeyEvent;
import java.awt.*;

public class Client {
    private String address;
    private int port;
    private Socket clientSocket;
    private BufferedReader in;
    private PrintWriter out;
    private Scanner scanner = new Scanner(System.in);
    private ClientView clientView;
    private LocalPlayer player;
    private GameViewType currentViewType;
    StringBuilder userNameBuilder = new StringBuilder();
    private ObjectMapper objectMapper = new ObjectMapper();
    private List<ActorPosition> actors;
    private List<ManagerSrc.Object> objects;
    private Integer[][] layout;
    private int levelId;
    private Integer[] currentPlayerPosn;
    private boolean ejected = false;

    public Client(String address, int port) throws Exception {
        this.address = address;
        this.port = port;
        this.currentViewType = GameViewType.START_SCREEN;
        this.actors = new ArrayList<>();
        this.objects = new ArrayList<>();
        this.layout = new Integer[5][5];
        clientSocket = new Socket(address, port);
        out = new PrintWriter(clientSocket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        this.player = null;
        this.clientView = null;
        this.levelId = 0;
        currentPlayerPosn = new Integer[2];
    }

    public void startConnection() throws Exception {

        String inputLine = in.readLine();
        System.out.println(inputLine); // welcome message

        while((inputLine = in.readLine()) != null) {
            System.out.println(inputLine);
            if (inputLine.equals("move")) {
                updateClientView();
                clientView.updateStoryPanel("Use arrow keys to make move and press enter when you are done!");
                clientView.setFocusable(true);
            } else if(inputLine.equals("OK")) {
                player.updatePlayerPosition(currentPlayerPosn);
                updateClientView();
            }
            else if (inputLine.equals("Invalid")) {
                currentPlayerPosn = player.getPosition();
                clientView.updateStoryPanel("Invalid move.");
                Thread.sleep(2000);
            } else if (inputLine.equals("Key")) {
                clientView.updateStoryPanel("Found key");
            } else if (inputLine.equals("Exit")) {
                currentViewType = GameViewType.LEVEL_END_SCREEN;
            } else if (inputLine.equals("Ejected")) {
                clientView.updateStoryPanel("You were ejected.");
                this.ejected = true;
            }
            else {
                JSONObject jsonObject = new JSONObject(inputLine);
                String type = (String) jsonObject.get("type");

                if(type.equals("name")) {
                    System.out.println("Please enter your name.");
                    String name = scanner.next();

                    this.player = new LocalPlayer(name);
                    out.println(name);
                    this.clientView = new ClientView(this, player.getName());
                }
                else if (type.equals("start-level")) {
                    currentViewType = GameViewType.START_SCREEN;

                    this.levelId = (int) jsonObject.getInt("level");
                    if(jsonObject.has("game")) {
                        start(levelId + 1, (int) jsonObject.getInt("game") + 1);
                    } else {
                        start(levelId + 1);
                    }
                } else if (type.equals("player-update")) {

                    String message = jsonObject.get("message").toString();
                    parsePlayerUpdate(jsonObject);
                    if(currentViewType == GameViewType.START_SCREEN) {
                        currentViewType = GameViewType.GAME_PLAY_SCREEN;
                        updateClientView();
                        clientView.beginGameScreen(player.getName());
                    } else if(currentViewType == GameViewType.LEVEL_END_SCREEN) {
                        updateClientView();
                        clientView.updateGameScreen();
                        clientView.updateStoryPanel("Found exit. You have passed the level!");
                    } else {
                        updateClientView();
                        clientView.updateGameScreen();
                        if(message != null) {
                            clientView.updateStoryPanel(message);
                        }
                    }

                    if(ejected) {
                        clientView.updateStoryPanel("You are dead.", 11);
                    }
                    Thread.sleep(2000);

                } else if(type.equals("end-game")) {

                    ejected = false;
                    currentViewType = GameViewType.END_GAME_SCREEN;

                    // if there are no more games, disconnect
                    if(jsonObject.has("leaderboard")) {
                        System.out.println(jsonObject.getJSONArray("leaderboard"));
                        clientView.endGameScreen("End of game. Hit enter if you want to exit.",
                                jsonObject.getJSONArray("scores"));
                        clientView.endGameScreen("End of all games. Check out the leaderboard:",
                                jsonObject.getJSONArray("leaderboard"));
                        disconnect();
                        break;
                    } else {
                        clientView.endGameScreen("End of game. Hit enter if you want to exit.",
                                jsonObject.getJSONArray("scores"));
                    }
                } else if(type.equals("end-level")) {

                    clientView.endLevelScreen(jsonObject.getString("key"), formatJSONArray(jsonObject.getJSONArray("exits")),
                            formatJSONArray(jsonObject.getJSONArray("ejects")));
                    ejected = false;
                }
                else {
                    System.out.println("Unknown");
                }
            }
        }
    }

    private String formatJSONArray(JSONArray jsonArr) {
        StringBuilder formatString = new StringBuilder();
        for(int i = 0; i < jsonArr.length(); i++) {
            formatString.append(jsonArr.get(i));
            if(i != jsonArr.length() - 1) {
                formatString.append(", ");
            }
        }

        if(formatString.toString().equals("")) {
            formatString = new StringBuilder("no one");
        }

        return formatString.toString();
    }

    private void parsePlayerUpdate(JSONObject jsonObject) throws Exception {
        String layoutString = jsonObject.get("layout").toString();
        layout = objectMapper.readValue(layoutString, Integer[][].class);

        String positionString = jsonObject.get("position").toString();
        Integer[] position = objectMapper.readValue(positionString, Integer[].class);
        player.updatePlayerPosition(position);

        String actorsString = jsonObject.get("actors").toString();
        actors = objectMapper.readValue(actorsString, new TypeReference<List<ActorPosition>>() {});

        String objectsString = jsonObject.get("objects").toString();
        objects = objectMapper.readValue(objectsString, new TypeReference<List<ManagerSrc.Object>>() {
        });
    }

    /**
     * Renders player view.
     */
    private void start(int levelId) throws Exception {
        gameIntro(levelId);
    }

    private void start(int levelId, int gameId) throws Exception {
        gameIntro(levelId, gameId);
    }

    private void updateClientView() {
        clientView.setCurrentPlayerPosn(player.getPosition());
        clientView.setLayout(layout);
        clientView.setActors(actors);
        System.out.println("Updating CLIENT");
        //System.out.println(actors.stream().filter(i -> !i.getType().equals(ActorType.player)).findFirst().get().getName());
        clientView.setObjects(objects);
    }

    private void gameIntro(int levelId) throws Exception {
        clientView.welcomeScreen(levelId);
    }

    private void gameIntro(int levelId, int gameId) throws Exception {
        clientView.welcomeScreen(levelId, gameId);
    }

    public void transitionScreens(int keyCode, char keyChar, boolean isActionKey, Integer[] playerPosn) {
        if (currentViewType.equals(GameViewType.GAME_PLAY_SCREEN) && keyCode == KeyEvent.VK_ENTER) {
            try {
                JSONObject playerMove = new JSONObject();
                playerMove.put("type", "move");

                Integer[] position = player.getPosition();

                playerMove.put("to", "");
                if(position[0] != playerPosn[0] || position[1] != playerPosn[1]) {
                    playerMove.put("to", playerPosn);
                }
                currentPlayerPosn = playerPosn;
                out.println(playerMove);
            } catch (Exception e) {
                System.out.println(e);
            }
        } else if (currentViewType.equals(GameViewType.MENU_SCREEN)) {
            // TODO: CLEANUP
            // i love this view which lets the user type thier name on the gui. but lets keep this in the cmd line for now till the network stuff is sorted out
            if (keyCode == KeyEvent.VK_ENTER) {
                //clientView.beginGameScreen();
            } else if (!isActionKey) {
                if (userNameBuilder.length() > 0 && keyCode == KeyEvent.VK_BACK_SPACE || keyCode == KeyEvent.VK_DELETE) {
                    userNameBuilder.setLength(userNameBuilder.length() - 1);
                } else {
                    userNameBuilder.append(keyChar);
                }
                //clientView.gameMenuScreen(userNameBuilder.toString());
            }
        } else if (currentViewType.equals(GameViewType.END_GAME_SCREEN) && keyCode == KeyEvent.VK_ENTER) {
            // shutting down game
            try {
                disconnect();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        else {
            // random keys being pressed, do nothing
        }
    }

    private void disconnect() throws Exception {
        clientView.setVisible(false);
        clientView.dispose();
        in.close();
        out.close();
        clientSocket.close();
    }
}
