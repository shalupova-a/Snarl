package Remote;

public enum MessageType {
    WELCOME, NAME, START_LEVEL, PLAYER_UPDATE, PLAYER_MOVE, RESULT, END_LEVEL, END_GAME;

    public String determineJSONString() throws Exception {
        switch(this) {
            case WELCOME:
                return "welcome";
            case NAME:
                return "name";
            case START_LEVEL:
                return "start-level";
            case PLAYER_UPDATE:
                return "player-update";
            case PLAYER_MOVE:
                return "move";
            case RESULT:
                return null;
            case END_LEVEL:
                return "end-level";
            case END_GAME:
                return "end-game";
            default:
                throw new Exception("MessageType doesn't exist.");
        }
    }
}