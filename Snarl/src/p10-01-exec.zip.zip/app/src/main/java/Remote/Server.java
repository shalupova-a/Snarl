package Remote;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.json.*;
import ManagerSrc.*;
import Game.Model.Coordinate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class Server {
    private static final int MAX_PLAYERS = 4;
    private int maxPlayers;
    private ServerSocket serverSocket;
    private BufferedReader in;
    private PrintWriter out;
    private String host;
    private int port;
    private GameManager manager;
    private List<Socket> sockets;
    private List<Level> levels;
    private boolean isObserver;
    private Map<Socket, LocalPlayer> socketMap;
    private Map<String, JSONObject> playerScoreMap;
    private JSONObject endLevelJSON;
    private Map<String, JSONObject> leaderboard;
    private Level currentLevel;
    private List<String> names;
    private ObjectMapper objectMapper = new ObjectMapper();
    private int levelId;
    private boolean progressLevel = false;
    private boolean progressGame = false;
    private ClientView asciiView;
    private int wait;
    private int numGames;
    private int gameId;

    public Server(String host, int port, int maxPlayers, JSONArray levels, boolean isObserver, int wait, int games) throws Exception {
        this.host = host;
        this.port = port;
        this.sockets = new ArrayList<>();
        if (maxPlayers > MAX_PLAYERS) {
            this.maxPlayers = MAX_PLAYERS;
        } else {
            this.maxPlayers = maxPlayers;
        }
        this.levels = objectMapper.readValue(levels.toString(), new TypeReference<List<Level>>() {});
        this.isObserver = isObserver;
        this.levelId = 0;
        this.currentLevel = this.levels.get(0);
        this.names = new ArrayList<>();
        this.socketMap = new LinkedHashMap<>();
        if(this.isObserver) {
            this.asciiView = new ClientView(currentLevel);
        }
        this.wait = wait;
        this.numGames = games;
        this.playerScoreMap = new HashMap<>();
        this.leaderboard = new HashMap<>();
    }

    private JSONObject createInitState() throws Exception {
        JSONArray jsonPlayers = initPlayers();
        JSONArray jsonAdversaries = initAdversaries();
        JSONObject jsonState = new JSONObject().put("type", "state");
        jsonState.put("players", jsonPlayers);
        jsonState.put("adversaries", jsonAdversaries);
        jsonState.put("exit-locked", true);
        jsonState.put("level", new JSONObject(objectMapper.writeValueAsString(currentLevel)));
        return jsonState;
    }

    private JSONArray initPlayers() {
        JSONArray jsonPlayers = new JSONArray();
        for (LocalPlayer player : socketMap.values()) {
            JSONObject jsonPlayer = new JSONObject();
            jsonPlayer.put("type", "player");
            jsonPlayer.put("name", player.getName());
            jsonPlayer.put("position", new JSONArray());
            jsonPlayers.put(jsonPlayer);
        }
        return jsonPlayers;
    }

    private JSONArray initAdversaries() {

        JSONArray jsonAdversaries = new JSONArray();
        for (int i = 0; i < this.levelId + 2; i++) {
            // random zombie and adversary
            ActorType actorType = i % 2 == 0 ? ActorType.ghost : ActorType.zombie;
            JSONObject jsonAdversary = new JSONObject();
            jsonAdversary.put("type", actorType.getName());
            jsonAdversary.put("name", i);
            jsonAdversary.put("position", new JSONArray());
            jsonAdversaries.put(jsonAdversary);
        }
        return jsonAdversaries;
    }


    public void startConnection() throws Exception {

        serverSocket = new ServerSocket(port);
        System.out.println("Waiting for " + maxPlayers + " users to register.");

        waitForPlayers(maxPlayers);

        sendMessageToAll(MessageType.WELCOME, "Welcome to the Snarl Game!" +
                "\nAuthors: Angelina Shalupova, Sheetal Singh" +
                "\nGithub Repo: Ilievrad");
        // asks and gets name
        sendMessageToAll(MessageType.NAME, "Please enter your name.");

        for(int i = 0; i < this.numGames; i++) {

            this.gameId = i;

            // start levels over for each game
            for (int j = 0; j < levels.size(); j++) {
                this.currentLevel = levels.get(j);
                this.levelId = j;
                initEndLevelJSON();
                State state = objectMapper.readValue(createInitState().toString(), State.class);
                this.manager = new GameManager(state);
                updateInitialPlayerLocations();
                sendMessageToAll(MessageType.START_LEVEL, "");
                Thread.sleep(10000);
                sendPlayerUpdate(state, "");
                if (this.isObserver) {
                    asciiView.beginGameScreenObserver("Observer", this.currentLevel, this.manager.getState().getPlayers(), this.manager.getState().getAdversaries());
                }
                while (!progressGame) {
                    System.out.println("Sending move request");
                    sendMoveRequest();
                }
                progressGame = false;
                uneject();
                if(!progressLevel) {
                    System.out.println("Not progressing level");
                    break;
                }
                progressLevel = false;


	        }
            sendMessageToAll(MessageType.END_GAME, "");

            clearPlayerScoreMap();
            System.out.println(playerScoreMap);
            //TODO update observer
        }
        disconnect();
    }

    private void initEndLevelJSON() {
        this.endLevelJSON = new JSONObject();
        endLevelJSON.put("type", "end-level");
        endLevelJSON.put("key", "");
        endLevelJSON.put("exits", new JSONArray());
        endLevelJSON.put("ejects", new JSONArray());
    }

    private void waitForPlayers(int numPlayers) throws Exception {
        for(int i = 0; i < numPlayers; i++) {
            Socket socket;
            try {
                serverSocket.setSoTimeout(this.wait * 1000);
                socket = serverSocket.accept();
                System.out.println("Connected to: " + socket.getRemoteSocketAddress());
                sockets.add(socket);
            } catch (IOException e) {
                System.out.println(e);
                System.exit(0);
            }
        }
    }

    private void sendMessageToAll(MessageType messageType, String message) throws Exception {
        for(Socket socket : this.sockets) {
            try {
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                JSONObject jsonMsg = new JSONObject();
                jsonMsg.put("type", messageType.determineJSONString());

                if(messageType == MessageType.NAME) {
                    jsonMsg.put("info", message);
                    out.println(jsonMsg);
                    String name = in.readLine();
                    while (!checkValidName(name, getNames())) {
                        jsonMsg.put("info", "Name already taken. " + message);
                        out.println(jsonMsg);
                        name = in.readLine();
                    }
                    names.add(name);
                    socketMap.put(socket, new LocalPlayer(name));
                    playerScoreMap.put(name, createPlayerScore(name));
                    leaderboard.put(name, createPlayerScore(name));
                }
                else if(messageType == MessageType.START_LEVEL) {
                    jsonMsg.put("level", levelId);
                    jsonMsg.put("players", getNames());
                    if(numGames > 1) {
                        jsonMsg.put("game", gameId);
                    }
                    out.println(jsonMsg);
                } else if(messageType == MessageType.END_LEVEL){
                    jsonMsg.put("key", endLevelJSON.get("key"));
                    jsonMsg.put("exits", endLevelJSON.get("exits"));
                    jsonMsg.put("ejects", endLevelJSON.get("ejects"));
                    out.println(jsonMsg);
                    Thread.sleep(5000);
                }
                else if(messageType == MessageType.END_GAME) {

                    jsonMsg.put("scores", getPlayerScoreArray(playerScoreMap));
                    if(this.gameId + 1 == this.numGames) {
                        jsonMsg.put("leaderboard", getPlayerScoreArray(leaderboard));
                        out.println(jsonMsg);
                        Thread.sleep(2000);
                        disconnect();
                    } else {
                        out.println(jsonMsg);
                    }

                } else {
                    jsonMsg.put("info", message);
                    out.println(jsonMsg);
                }
            }
            catch(IOException e) {
                System.out.println(e);
                System.exit(0);
            }
        }
    }

    private JSONObject createPlayerScore(String name) {
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("type", "player-score");
        jsonObj.put("name", name);
        jsonObj.put("exits", 0);
        jsonObj.put("ejects", 0);
        jsonObj.put("keys", 0);
        return jsonObj;
    }

    private JSONArray getPlayerScoreArray(Map<String, JSONObject> playerScoreMap) {
        JSONArray playerScoreArray = new JSONArray();
        for(JSONObject jsonObj : playerScoreMap.values()) {
            playerScoreArray.put(jsonObj);
        }
        return playerScoreArray;
    }

    public void sendPlayerUpdate(State state, String message) throws Exception {
        for (Map.Entry mapElement : socketMap.entrySet()) {
            try {
                Socket socket = (Socket) mapElement.getKey();
                LocalPlayer localPlayer = (LocalPlayer) mapElement.getValue();

                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                int[][] layout = this.manager.getLayout(localPlayer.getPosition());
                JSONObject jsonMsg = new JSONObject();
                jsonMsg.put("type", MessageType.PLAYER_UPDATE.determineJSONString());
                jsonMsg.put("layout", objectMapper.writeValueAsString(layout));
                jsonMsg.put("position", new JSONArray(localPlayer.getPosition()));
                jsonMsg.put("objects", objectMapper.writeValueAsString(
                        this.manager.getNearbyObjects(localPlayer.getPosition())));
                jsonMsg.put("actors", objectMapper.writeValueAsString(
                        this.manager.getNearbyActors(localPlayer.getPosition())));

                jsonMsg.put("message", message);

                System.out.println("Sending player update");
                System.out.println(jsonMsg.toString());
                out.println(jsonMsg);

                if(this.isObserver) {
                    asciiView.updateGameScreenObserver(this.currentLevel, this.manager.getState().getActors());
                    if(!message.equals("")) {
                        asciiView.updateStoryPanel(message);
                    }
                }

            } catch(IOException e) {
                System.out.println(e);
                System.exit(0);
            }
        }
    }

    public void sendMoveRequest() throws Exception {
        for (Map.Entry mapElement : socketMap.entrySet()) {
            Socket socket = (Socket) mapElement.getKey();
            LocalPlayer localPlayer = (LocalPlayer) mapElement.getValue();
            try {
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                boolean validMove = false;
                int moves = 0;
                String message = "";
                while (!validMove && moves < 3 && !localPlayer.getExpelled()) {
                    // in case previous adversary move expelled player
                    if(checkExpelled(localPlayer)) {
                        expel(localPlayer);
                        out.println("Ejected");
                        sendPlayerUpdate(this.manager.getState(), "player " + localPlayer.getName() + " died");
                        break;
                    }

                    moves++;
                    out.println("move");
                    String response = in.readLine();
                    System.out.println(response);
                    JSONObject playerMove = new JSONObject(response);
                    if (playerMove.get("to").equals("")) {
                        out.println("OK");
                        validMove = true;
                        message = "player " + localPlayer.getName() + " stayed put.";
                    } else {
                        Integer[] to = objectMapper.readValue(playerMove.get("to").toString(), Integer[].class);
                        if (this.manager.checkValidMove(localPlayer.getPosition(), to)) {
                            validMove = true;
                            localPlayer.updatePlayerPosition(to);
                            socketMap.put(socket, localPlayer);
                            updatePlayerLocations();
                            if (this.manager.foundKey(to)) {
                                out.println("Key");
                                updatePlayerScoreMap(localPlayer.getName(), "keys");
                                endLevelJSON.put("key", localPlayer.getName());
                                this.currentLevel.getObjects().removeIf(o -> o.getType().equals("key")); //TODO don't remove in both places?
                                this.manager.removeKey();
                                message = "player " + localPlayer.getName() + " found key";
                            } else if (!this.manager.isExitLocked() && this.manager.exited(to)) {
                                out.println("Exit");
                                updatePlayerScoreMap(localPlayer.getName(), "exits");
                                endLevelJSON.put("exits", endLevelJSON.getJSONArray("exits").put(localPlayer.getName()));
                                message = "player " + localPlayer.getName() + " exited";
                                this.manager.getState().removePlayer(localPlayer.getName());
                                localPlayer.setExpelled(true);
                                progressLevel = true;
                            } else if (this.manager.ejected(to)) {
                                out.println("Ejected");
                                message = "player " + localPlayer.getName() + " died";
                                expel(localPlayer);
                            } else {
                                out.println("OK");
                                message = "player " + localPlayer.getName() + " moved";
                            }
                        } else {

                            out.println("Invalid");
                        }
                    }
                }
                sendPlayerUpdate(this.manager.getState(), message);

            } catch (IOException e) {
                System.out.println(e);
                socketMap = socketMap.entrySet()
                        .stream()
                        .filter(entry -> !checkNameEquality((LocalPlayer) entry.getValue(), localPlayer.getName()))
                        .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
                this.manager.getState().removePlayer(localPlayer.getName());
                sendPlayerUpdate(this.manager.getState(), "player " + localPlayer.getName() + " disconnected.");
                if(socketMap.isEmpty()) {
                    if(isObserver) {
                        asciiView.updateStoryPanel("All clients disconnected.");
                        Thread.sleep(1000);
                    }
                    System.exit(0);
                }
            }
        }

        if(allPlayersExpelled()) {
            System.out.println("all players expelled");
            progressGame = true;
            if(progressLevel) {
                sendMessageToAll(MessageType.END_LEVEL, "");
            } else {
                System.out.println("lost");
            }
        }

        this.manager.beckonAdversaryMove();
        sendPlayerUpdate(this.manager.getState(), "adversaries moved.");
    }

    private boolean allPlayersExpelled() {
        return socketMap.entrySet()
                .stream()
                .allMatch(entry -> ((LocalPlayer) entry.getValue()).getExpelled());
    }

    private boolean checkExpelled(LocalPlayer player) throws Exception {
        return this.manager.ejected(player.getPosition());
    }

    private void expel(LocalPlayer localPlayer) {

        updatePlayerScoreMap(localPlayer.getName(), "ejects");
        endLevelJSON.put("ejects", endLevelJSON.getJSONArray("ejects").put(localPlayer.getName()));
        // set player to expelled in game state
        this.manager.getState().removePlayer(localPlayer.getName());
        localPlayer.setExpelled(true);
    }

    private boolean checkNameEquality(LocalPlayer player, String name) {

        return player.getName().equals(name);
    }

    private void updatePlayerScoreMap(String name, String key) {
        JSONObject playerScore = playerScoreMap.get(name);
        playerScore.put(key, playerScore.getInt(key) + 1);
        playerScore = leaderboard.get(name);
        playerScore.put(key, playerScore.getInt(key) + 1);
    }

    private void clearPlayerScoreMap() {
        playerScoreMap = new HashMap<>();
        for(String name : names) {
            playerScoreMap.put(name, createPlayerScore(name));
        }
    }

    private boolean checkValidName(String name, List<String> names) {

        for(String n : names) {
            if(n.equals(name)) {
                System.out.println("Invalid name!");
                return false;
            }
        }

        return true;
    }

    private List<String> getNames() {
        List<String> names = new ArrayList<>();
        for(LocalPlayer player : socketMap.values()) {
            names.add(player.getName());
        }

        return names;
    }

    private void updatePlayerLocations() throws Exception {
        List<ActorPosition> players = this.manager.getState().getPlayers();

        for(LocalPlayer player : socketMap.values()) {
            for(ActorPosition actor : players) {
                if(player.getName().equals(actor.getName())) {
                    actor.setPosition(player.getPosition());
                }
            }
        }
    }

    private void updateInitialPlayerLocations() throws Exception {
        List<ActorPosition> players = this.manager.getState().getPlayers();

        for(LocalPlayer player : socketMap.values()) {
            for(ActorPosition actor : players) {
                if(player.getName().equals(actor.getName())) {
                    player.updatePlayerPosition(actor.getPosition());
                }
            }
        }
    }


    private void uneject() {
        for (Map.Entry mapElement : socketMap.entrySet()) {
            LocalPlayer player = (LocalPlayer) mapElement.getValue();
            player.setExpelled(false);
        }
    }

    private void disconnect() throws Exception {
        if(isObserver) {
            asciiView.setVisible(false);
            asciiView.dispose();
        }
        in.close();
        out.close();
        serverSocket.close();
    }
}